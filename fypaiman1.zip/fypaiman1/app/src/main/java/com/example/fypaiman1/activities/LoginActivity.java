package com.example.fypaiman1.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.SplashScreen;

import com.example.fypaiman1.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

// --- IMPORT ONESIGNAL ---
import com.onesignal.OneSignal;
import com.onesignal.Continue;

public class LoginActivity extends AppCompatActivity {

    // --- TAMBAH APP ID ONESIGNAL KAT SINI ---
    // (Kalau kau ada App ID kau sendiri kat website OneSignal, tukar yang ni)
    private static final String ONESIGNAL_APP_ID = "281499fa-c066-4510-9b3b-026569a3d8a6";

    private EditText etEmail, etPassword;
    private Button btnLogin;
    private TextView tvGoToSignUp, tvForgotPassword;

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // --- INSTALL SPLASH SCREEN ---
        SplashScreen.installSplashScreen(this);
        
        super.onCreate(savedInstanceState);

        // --- ONESIGNAL: WAJIB INIT DULU SEBELUM BUAT APA-APA ---
        OneSignal.initWithContext(this, ONESIGNAL_APP_ID);
        // -----------------------------------------------------------

        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        SharedPreferences prefs = getSharedPreferences("KlinikSession", MODE_PRIVATE);

        // --- ONESIGNAL: Request notification permission (Android 13+) ---
        OneSignal.getNotifications().requestPermission(true, Continue.with(r -> {
            if (r.isSuccess()) {
                if (r.getData()) {
                    Log.d("OneSignal", "Permission granted by patient!");
                } else {
                    Log.d("OneSignal", "Permission denied!");
                }
            }
        }));
        // -----------------------------------------------------------

        // --- PREVENT 'PING PONG' LOOP ---
        if (currentUser == null) {
            prefs.edit().putBoolean("isLoggedIn", false).putString("userRole", "").apply();
        }

        // --- STEP 1: CHECK MEMORY BEFORE OPENING LOGIN SCREEN ---
        boolean isLoggedIn = prefs.getBoolean("isLoggedIn", false);

        if (isLoggedIn) {
            String role = prefs.getString("userRole", "");

            if ("Patient".equalsIgnoreCase(role)) {
                startActivity(new Intent(LoginActivity.this, PatientDashboardActivity.class));
                finish();
                return;
            } else if ("Doctor".equalsIgnoreCase(role)) {
                startActivity(new Intent(LoginActivity.this, DoctorDashboardActivity.class));
                finish();
                return;
            } else if ("Admin".equalsIgnoreCase(role)) {
                // --- ADMIN CODE OPENED ---
                startActivity(new Intent(LoginActivity.this, AdminDashboardActivity.class));
                finish();
                return;
            }
        }
        // ---------------------------------------------------------

        setContentView(R.layout.activity_login);

        mDatabase = FirebaseDatabase.getInstance().getReference("Users");

        etEmail = findViewById(R.id.etEmailLogin);
        etPassword = findViewById(R.id.etPasswordLogin);
        btnLogin = findViewById(R.id.btnLogin);
        tvGoToSignUp = findViewById(R.id.tvGoToSignUp);
        tvForgotPassword = findViewById(R.id.tvForgotPassword);

        tvGoToSignUp.setOnClickListener(v -> startActivity(new Intent(LoginActivity.this, SignUpActivity.class)));

        btnLogin.setOnClickListener(v -> loginUser());

        tvForgotPassword.setOnClickListener(v -> resetPassword());
    }

    private void resetPassword() {
        String email = etEmail.getText().toString().trim();

        if (email.isEmpty()) {
            Toast.makeText(this, "Please type your email above before clicking Forgot Password", Toast.LENGTH_LONG).show();
            etEmail.setError("Enter email here");
            etEmail.requestFocus();
            return;
        }

        mAuth.sendPasswordResetEmail(email)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(LoginActivity.this, "Success! Please check your email inbox/spam.", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(LoginActivity.this, "Failed: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void loginUser() {
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter your email and password", Toast.LENGTH_SHORT).show();
            return;
        }

        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        checkUserRole();
                    } else {
                        Toast.makeText(LoginActivity.this, "Login failed: Please check your email/password", Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void checkUserRole() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;

        String userId = currentUser.getUid();

        // --- ONESIGNAL: Important binding! Tell server this device ID ---
        OneSignal.login(userId);
        Log.d("OneSignal", "Successfully logged into OneSignal with ID: " + userId);
        // ----------------------------------------------------------------------

        mDatabase.child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String role = snapshot.child("role").getValue(String.class);

                    if (role != null) {

                        SharedPreferences prefs = getSharedPreferences("KlinikSession", MODE_PRIVATE);
                        SharedPreferences.Editor editor = prefs.edit();
                        editor.putBoolean("isLoggedIn", true);
                        editor.putString("userRole", role);
                        editor.apply();

                        if (role.equalsIgnoreCase("Patient")) {
                            Toast.makeText(LoginActivity.this, "Welcome Patient!", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(LoginActivity.this, PatientDashboardActivity.class));
                            finish();
                        } else if (role.equalsIgnoreCase("Doctor")) {
                            Toast.makeText(LoginActivity.this, "Welcome Doctor!", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(LoginActivity.this, DoctorDashboardActivity.class));
                            finish();
                        } else if (role.equalsIgnoreCase("Admin")) {
                            Toast.makeText(LoginActivity.this, "Welcome Admin!", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(LoginActivity.this, AdminDashboardActivity.class));
                            finish();
                        } else {
                            Toast.makeText(LoginActivity.this, "Unrecognized role: " + role, Toast.LENGTH_LONG).show();
                        }
                    } else {
                        Toast.makeText(LoginActivity.this, "Error: No role assigned!", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(LoginActivity.this, "Error: Profile data missing!", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(LoginActivity.this, "Connection error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}