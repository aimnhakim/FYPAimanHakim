package com.example.fypaiman1.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fypaiman1.R;
import com.example.fypaiman1.models.QueueItem;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;

public class PharmacyAdapter extends RecyclerView.Adapter<PharmacyAdapter.PharmacyViewHolder> {

    private Context context;
    private List<QueueItem> queueList;

    public PharmacyAdapter(Context context, List<QueueItem> queueList) {
        this.context = context;
        this.queueList = queueList;
    }

    @NonNull
    @Override
    public PharmacyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_pharmacy_queue, parent, false);
        return new PharmacyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PharmacyViewHolder holder, int position) {
        QueueItem item = queueList.get(position);

        // --- GUNA GETSAFEQUEUEID SUPAYA TAK NULL ---
        String safeId = item.getSafeQueueId();

        if (safeId == null) {
            holder.tvQueueId.setText("ID: Error");
            holder.tvPatientName.setText("Patient: Unknown");
            holder.tvUbat.setText("Data corrupted.");
            holder.btnSelesai.setEnabled(false);
            return;
        }

        holder.tvQueueId.setText("Queue No: " + safeId);
        holder.tvPatientName.setText("Patient: " + item.getPatientName());

        // FETCH MEDICINE LIST FROM FIREBASE
        DatabaseReference ubatRef = FirebaseDatabase.getInstance().getReference("KlinikQueue")
                .child(safeId).child("prescriptions");

        ubatRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                StringBuilder sb = new StringBuilder("PRESCRIBED MEDICINE:\n");
                if (snapshot.exists()) {
                    for (DataSnapshot ds : snapshot.getChildren()) {
                        String nama = ds.child("namaUbat").getValue(String.class);
                        String freq = ds.child("kekerapan").getValue(String.class);

                        if (nama == null) nama = "Unknown";
                        if (freq == null) freq = "-";

                        sb.append("• ").append(nama).append(" (").append(freq).append(")\n");
                    }
                    holder.tvUbat.setText(sb.toString());
                } else {
                    holder.tvUbat.setText("Status: Waiting for prescription...");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                holder.tvUbat.setText("Error loading medication.");
            }
        });

        // --- COMPLETE BUTTON ---
        holder.btnSelesai.setOnClickListener(v -> {
            DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference("KlinikQueue")
                    .child(safeId);

            dbRef.child("status").setValue("Completed").addOnSuccessListener(aVoid -> {
                Toast.makeText(context, "Completed! Patient " + item.getPatientName() + " has collected the medicine.", Toast.LENGTH_SHORT).show();
            });
        });
    }

    @Override
    public int getItemCount() {
        return queueList.size();
    }

    public static class PharmacyViewHolder extends RecyclerView.ViewHolder {
        TextView tvQueueId, tvPatientName, tvUbat;
        Button btnSelesai;

        public PharmacyViewHolder(@NonNull View itemView) {
            super(itemView);
            tvQueueId = itemView.findViewById(R.id.tvPharQueueId);
            tvPatientName = itemView.findViewById(R.id.tvPharPatientName);
            tvUbat = itemView.findViewById(R.id.tvPharUbat);
            btnSelesai = itemView.findViewById(R.id.btnUrusUbat);
        }
    }
}