package com.example.fypaiman1.adapters;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fypaiman1.R;
import com.example.fypaiman1.models.QueueItem;
import com.example.fypaiman1.activities.DoctorConsultationActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class QueueAdapter extends RecyclerView.Adapter<QueueAdapter.QueueViewHolder> {

    private Context context;
    private List<QueueItem> queueList;
    private String roomNumber;

    // --- APP ID ---
    private static final String ONESIGNAL_APP_ID = "281499fa-c066-4510-9b3b-026569a3d8a6";
    // --- REST API KEY ---
    private static final String ONESIGNAL_REST_API_KEY = "os_v2_app_fakjt6wamzcrbgz3ajswti6yu3oqcdjmjb6ewqefy4hwm2bxji43w7mfpghc4qglqbtaxlq2jwj2cq4t2p5u7lc7ni2wftum47gltci";

    public QueueAdapter(Context context, List<QueueItem> queueList, String roomNumber) {
        this.context = context;
        this.queueList = queueList;
        this.roomNumber = roomNumber;
    }

    @NonNull
    @Override
    public QueueViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_queue_doctor, parent, false);
        return new QueueViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull QueueViewHolder holder, int position) {
        QueueItem item = queueList.get(position);

        // --- GUNA FUNGSI KEBAL KITA ---
        String safeQueueId = item.getSafeQueueId();

        // Kalau data rosak teruk (dua-dua null), kita skip supaya tak crash
        if (safeQueueId == null) {
            holder.tvQueueNumber.setText("ERROR");
            holder.tvPatientName.setText("Data Corrupted");
            holder.btnCall.setEnabled(false);
            return;
        }

        holder.tvQueueNumber.setText(safeQueueId);
        holder.tvPatientName.setText(item.getPatientName());

        holder.btnCall.setOnClickListener(v -> {
            // Sekarang dia panggil Firebase guna nombor yang confirm wujud!
            DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference("KlinikQueue").child(safeQueueId);

            dbRef.child("status").get().addOnCompleteListener(task -> {
                if (task.isSuccessful() && task.getResult().exists()) {
                    String currentStatus = task.getResult().getValue(String.class);

                    if ("Waiting".equals(currentStatus)) {
                        HashMap<String, Object> updateData = new HashMap<>();
                        updateData.put("status", "Consulting");
                        updateData.put("roomNumber", roomNumber);

                        dbRef.updateChildren(updateData).addOnSuccessListener(aVoid -> {

                            // Save session in SharedPreferences
                            SharedPreferences prefs = v.getContext().getSharedPreferences("KlinikSession", Context.MODE_PRIVATE);
                            SharedPreferences.Editor editor = prefs.edit();
                            editor.putString("active_queue_id", safeQueueId);
                            editor.putString("active_patient_name", item.getPatientName());
                            editor.apply(); // Guna apply() lagi pantas dari commit()

                            // Send notification to patient
                            sendNotificationToPatient(item.getPatientId(), safeQueueId);

                            Toast.makeText(v.getContext(), "Patient " + safeQueueId + " called!", Toast.LENGTH_SHORT).show();

                            // Open doctor consultation view
                            Intent intent = new Intent(v.getContext(), DoctorConsultationActivity.class);
                            intent.putExtra("QUEUE_ID", safeQueueId);
                            intent.putExtra("PATIENT_NAME", item.getPatientName());
                            v.getContext().startActivity(intent);

                        }).addOnFailureListener(e -> {
                            Toast.makeText(v.getContext(), "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        });
                    } else {
                        Toast.makeText(v.getContext(), "⚠️ Patient already called by another doctor!", Toast.LENGTH_LONG).show();
                    }
                }
            });
        });
    }

    private void sendNotificationToPatient(String patientFirebaseId, String queueNumber) {
        if (patientFirebaseId == null || patientFirebaseId.isEmpty()) {
            Log.e("OneSignalAPI", "Patient Firebase ID is empty!");
            return;
        }

        OkHttpClient client = new OkHttpClient();

        String message = "Queue " + queueNumber + ", please enter Room " + roomNumber + " now.";

        String jsonBody = "{"
                + "\"app_id\": \"" + ONESIGNAL_APP_ID + "\","
                + "\"target_channel\": \"push\","
                + "\"include_aliases\": {"
                + "    \"external_id\": [\"" + patientFirebaseId + "\"]"
                + "},"
                + "\"headings\": {\"en\": \"It's Your Turn!\"},"
                + "\"contents\": {\"en\": \"" + message + "\"}"
                + "}";

        RequestBody body = RequestBody.create(jsonBody, MediaType.parse("application/json; charset=utf-8"));

        Request request = new Request.Builder()
                .url("https://api.onesignal.com/notifications")
                .post(body)
                .addHeader("Authorization", "key " + ONESIGNAL_REST_API_KEY)
                .addHeader("Content-Type", "application/json; charset=utf-8")
                .addHeader("Accept", "application/json")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                Log.e("OneSignalAPI", "Failed to send request: " + e.getMessage());
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    Log.d("OneSignalAPI", "SUCCESS! Server Response: " + response.body().string());
                } else {
                    Log.e("OneSignalAPI", "FAIL! Server Error: " + response.code() + " - " + response.body().string());
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return queueList.size();
    }

    public static class QueueViewHolder extends RecyclerView.ViewHolder {
        TextView tvQueueNumber, tvPatientName;
        Button btnCall;

        public QueueViewHolder(@NonNull View itemView) {
            super(itemView);
            tvQueueNumber = itemView.findViewById(R.id.tvQueueNumber);
            tvPatientName = itemView.findViewById(R.id.tvPatientName);
            btnCall = itemView.findViewById(R.id.btnCall);
        }
    }
}