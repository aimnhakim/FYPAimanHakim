package com.example.fypaiman1.activities;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat; // Tambah import ni untuk fix deprecation
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fypaiman1.R;
import com.example.fypaiman1.models.QueueItem;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class AdminManageQueueActivity extends AppCompatActivity {

    private TextView tvCurrentQueueNo, tvCurrentRoom;
    private RecyclerView rvWaitingList;
    private Button btnResetQueue;
    private LinearLayout layoutEmptyQueue;
    private DatabaseReference queueRef;

    private List<QueueItem> waitingList;
    private QueueAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_manage_queue);

        // --- 1. SETUP TOOLBAR ---
        Toolbar toolbar = findViewById(R.id.toolbarQueue);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Manage Queue");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());

        // --- 2. BIND UI COMPONENTS ---
        tvCurrentQueueNo = findViewById(R.id.tvCurrentQueueNo);
        tvCurrentRoom = findViewById(R.id.tvCurrentRoom);
        rvWaitingList = findViewById(R.id.rvWaitingList);
        btnResetQueue = findViewById(R.id.btnResetQueue);
        layoutEmptyQueue = findViewById(R.id.layoutEmptyQueue);

        rvWaitingList.setLayoutManager(new LinearLayoutManager(this));
        waitingList = new ArrayList<>();
        adapter = new QueueAdapter(waitingList);
        rvWaitingList.setAdapter(adapter);

        // --- 3. FIREBASE SINGAPORE URL SETUP ---
        String firebase_url = "https://finalyearproject-f9e19-default-rtdb.asia-southeast1.firebasedatabase.app/";
        queueRef = FirebaseDatabase.getInstance(firebase_url).getReference("KlinikQueue");

        // --- 4. REAL-TIME QUEUE MONITORING ---
        queueRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                waitingList.clear();
                boolean isAnyCalling = false;

                for (DataSnapshot ds : snapshot.getChildren()) {
                    QueueItem item = ds.getValue(QueueItem.class);
                    if (item != null && item.status != null) {

                        // Terima status "Calling" atau "Consulting"
                        if ("Calling".equalsIgnoreCase(item.status) || "Consulting".equalsIgnoreCase(item.status)) {
                            tvCurrentQueueNo.setText(item.getSafeQueueId());

                            if (item.roomNumber != null && !item.roomNumber.isEmpty()) {
                                tvCurrentRoom.setText("Proceed to: " + item.roomNumber);
                            } else {
                                tvCurrentRoom.setText("Proceed to: Doctor's Room");
                            }

                            // 🔥 FIX DEPRECATION 1: Guna ContextCompat
                            tvCurrentQueueNo.setTextColor(ContextCompat.getColor(AdminManageQueueActivity.this, android.R.color.holo_green_dark));
                            isAnyCalling = true;
                        }
                        // Status "Waiting"
                        else if ("Waiting".equalsIgnoreCase(item.status)) {
                            waitingList.add(item);
                        }
                    }
                }

                // If no active calling or consulting, reset display
                if (!isAnyCalling) {
                    tvCurrentQueueNo.setText("----");
                    tvCurrentRoom.setText("Waiting for call...");
                    // 🔥 FIX DEPRECATION 2: Guna ContextCompat
                    tvCurrentQueueNo.setTextColor(ContextCompat.getColor(AdminManageQueueActivity.this, android.R.color.darker_gray));
                }

                // --- LOGIK EMPTY STATE ---
                if (waitingList.isEmpty()) {
                    layoutEmptyQueue.setVisibility(View.VISIBLE);
                    rvWaitingList.setVisibility(View.GONE);
                } else {
                    layoutEmptyQueue.setVisibility(View.GONE);
                    rvWaitingList.setVisibility(View.VISIBLE);
                }

                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(AdminManageQueueActivity.this, "Database Error: " + error.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

        // --- 5. RESET SYSTEM FUNCTION ---
        btnResetQueue.setOnClickListener(v -> {
            queueRef.removeValue().addOnCompleteListener(task -> {
                if(task.isSuccessful()){
                    Toast.makeText(AdminManageQueueActivity.this, "Queue system has been reset for today.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(AdminManageQueueActivity.this, "Reset failed. Try again.", Toast.LENGTH_SHORT).show();
                }
            });
        });
    }

    // --- INNER ADAPTER CLASS ---
    private class QueueAdapter extends RecyclerView.Adapter<QueueAdapter.ViewHolder> {
        private List<QueueItem> localList;

        public QueueAdapter(List<QueueItem> localList) {
            this.localList = localList;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_queue, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            QueueItem item = localList.get(position);

            holder.tvQueueNo.setText(item.getSafeQueueId());
            holder.tvName.setText(item.patientName);
            holder.tvStatus.setText(item.status);
        }

        @Override
        public int getItemCount() {
            return localList.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvQueueNo, tvName, tvStatus;
            ViewHolder(View itemView) {
                super(itemView);
                tvQueueNo = itemView.findViewById(R.id.tvItemQueueNo);
                tvName = itemView.findViewById(R.id.tvItemPatientName);
                tvStatus = itemView.findViewById(R.id.tvItemStatus);
            }
        }
    }
}