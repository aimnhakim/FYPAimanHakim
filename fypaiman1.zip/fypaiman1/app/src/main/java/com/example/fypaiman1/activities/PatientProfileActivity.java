package com.example.fypaiman1.activities;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.example.fypaiman1.R;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.HashMap;

public class PatientProfileActivity extends AppCompatActivity {

    private EditText etProfileName, etProfileEmail, etProfileMatric, etProfileAllergies, etProfilePhone;
    private MaterialButton btnSaveProfile;
    private DatabaseReference userRef;
    private FirebaseUser currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_profile);

        // --- SETUP TOOLBAR ---
        Toolbar toolbar = findViewById(R.id.toolbarProfile);
        toolbar.setNavigationOnClickListener(v -> finish()); // Tekan arrow back untuk keluar

        etProfileName = findViewById(R.id.etProfileName);
        etProfileEmail = findViewById(R.id.etProfileEmail);
        etProfileMatric = findViewById(R.id.etProfileMatric);
        etProfileAllergies = findViewById(R.id.etProfileAllergies);
        etProfilePhone = findViewById(R.id.etProfilePhone); // TAMBAH UNTUK PHONE NUMBER
        btnSaveProfile = findViewById(R.id.btnSaveProfile);

        // --- KUNCI KOTAK SUPAYA TAK BOLEH DIUBAH ---
        etProfileName.setEnabled(false);
        etProfileEmail.setEnabled(false);
        etProfileMatric.setEnabled(false);

        currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            userRef = FirebaseDatabase.getInstance().getReference("Users").child(currentUser.getUid());
            loadUserProfile();
        }

        btnSaveProfile.setOnClickListener(v -> saveUserProfile());
    }

    private void loadUserProfile() {
        etProfileEmail.setText(currentUser.getEmail());
        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    etProfileName.setText(snapshot.child("fullName").getValue(String.class));
                    etProfileMatric.setText(snapshot.child("matricId").getValue(String.class));
                    etProfileAllergies.setText(snapshot.child("allergies").getValue(String.class));

                    // Tarik nombor telefon dari database (kalau ada)
                    if (snapshot.hasChild("phone")) {
                        etProfilePhone.setText(snapshot.child("phone").getValue(String.class));
                    }
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void saveUserProfile() {
        // Kita cuma save bahagian yang dibenarkan untuk ubah (Phone & Allergies)
        String phone = etProfilePhone.getText().toString().trim();
        String allergies = etProfileAllergies.getText().toString().trim();

        if (phone.isEmpty()) {
            etProfilePhone.setError("Phone number required");
            return;
        }

        HashMap<String, Object> updates = new HashMap<>();
        updates.put("phone", phone);
        updates.put("allergies", allergies);

        userRef.updateChildren(updates).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(this, "Profile Updated Successfully", Toast.LENGTH_SHORT).show();
                finish(); // Tutup page lepas siap save
            } else {
                Toast.makeText(this, "Failed to update profile", Toast.LENGTH_SHORT).show();
            }
        });
    }
}