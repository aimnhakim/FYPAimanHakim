package com.example.fypaiman1.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fypaiman1.R;
import com.example.fypaiman1.adapters.PrescriptionAdapter;
import com.example.fypaiman1.models.Prescription;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class DoctorPrescriptionActivity extends AppCompatActivity {

    // Dah tukar semua ke AutoCompleteTextView
    private AutoCompleteTextView autoNamaUbat, autoDosage, autoKekerapan, autoArahan;
    private Button btnTambahUbat, btnHantarUbat;
    private RecyclerView rvPrescription;

    private PrescriptionAdapter adapter;
    private List<Prescription> listUbat;
    private DatabaseReference dbRef;
    private String queueId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_prescription);

        // --- TOOLBAR SETUP ---
        Toolbar toolbar = findViewById(R.id.toolbarPrescription);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(true);
            getSupportActionBar().setTitle("Medical Prescription");
        }
        toolbar.setNavigationOnClickListener(v -> onBackPressed());

        queueId = getIntent().getStringExtra("QUEUE_ID");

        // 1. Bind UI
        autoNamaUbat = findViewById(R.id.autoNamaUbat);
        autoDosage = findViewById(R.id.autoDosage);
        autoKekerapan = findViewById(R.id.autoKekerapan);
        autoArahan = findViewById(R.id.autoArahan);

        btnTambahUbat = findViewById(R.id.btnTambahUbat);
        btnHantarUbat = findViewById(R.id.btnHantarUbat);
        rvPrescription = findViewById(R.id.rvPrescription);

        // 2. SETUP DROPDOWN LISTS (Hardcoded Data)
        String[] listMed = {"Paracetamol", "Ibuprofen", "Amoxicillin", "Vitamin C", "Cough Syrup", "Loratadine"};
        String[] listDos = {"1 Tablet", "2 Tablets", "1 Capsule", "5ml (1 Teaspoon)", "10ml"};
        String[] listFreq = {"1x Daily", "2x Daily", "3x Daily", "When Necessary"};
        String[] listInst = {"After Meal", "Before Meal", "Before Sleep"};

        // Set Adapters
        autoNamaUbat.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listMed));
        autoDosage.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listDos));
        autoKekerapan.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listFreq));
        autoArahan.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listInst));

        // 3. RecyclerView Setup
        rvPrescription.setLayoutManager(new LinearLayoutManager(this));
        listUbat = new ArrayList<>();
        adapter = new PrescriptionAdapter(this, listUbat, queueId);
        rvPrescription.setAdapter(adapter);

        dbRef = FirebaseDatabase.getInstance().getReference("KlinikQueue")
                .child(queueId).child("prescriptions");

        // Fetch live prescription list
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listUbat.clear();
                for (DataSnapshot data : snapshot.getChildren()) {
                    Prescription ubat = data.getValue(Prescription.class);
                    if (ubat != null) {
                        listUbat.add(ubat);
                    }
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(DoctorPrescriptionActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        // Add Medication Button
        btnTambahUbat.setOnClickListener(v -> tambahUbatKeFirebase());

        // SEND BUTTON
        btnHantarUbat.setOnClickListener(v -> {
            if (listUbat.isEmpty()) {
                Toast.makeText(this, "Please add at least one medication!", Toast.LENGTH_SHORT).show();
            } else {
                DatabaseReference queueRef = FirebaseDatabase.getInstance().getReference("KlinikQueue").child(queueId);
                queueRef.child("status").setValue("Pharmacy").addOnSuccessListener(aVoid -> {
                    new Handler(Looper.getMainLooper()).postDelayed(() -> {
                        queueRef.child("status").setValue("Completed");
                    }, 300000);

                    SharedPreferences prefs = getSharedPreferences("KlinikSession", MODE_PRIVATE);
                    prefs.edit().remove("active_queue_id").remove("active_patient_name").apply();

                    Toast.makeText(this, "Prescription Sent! Patient moved to Pharmacy.", Toast.LENGTH_LONG).show();

                    Intent intent = new Intent(DoctorPrescriptionActivity.this, DoctorDashboardActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();
                });
            }
        });
    }

    private void tambahUbatKeFirebase() {
        String nama = autoNamaUbat.getText().toString().trim();
        String dosage = autoDosage.getText().toString().trim(); // <-- AMBIL DOSAGE
        String kekerapan = autoKekerapan.getText().toString().trim();
        String arahan = autoArahan.getText().toString().trim();

        if (TextUtils.isEmpty(nama) || TextUtils.isEmpty(dosage) || TextUtils.isEmpty(kekerapan) || TextUtils.isEmpty(arahan)) {
            Toast.makeText(this, "Please select all medication details!", Toast.LENGTH_SHORT).show();
            return;
        }

        String ubatId = dbRef.push().getKey();
        // Masukkan dosage dalam constructor
        Prescription ubatBaru = new Prescription(ubatId, nama, dosage, kekerapan, arahan);

        if (ubatId != null) {
            dbRef.child(ubatId).setValue(ubatBaru).addOnSuccessListener(aVoid -> {
                Toast.makeText(this, "Medication added successfully", Toast.LENGTH_SHORT).show();
                // Kosongkan kotak lepas tambah
                autoNamaUbat.setText("", false);
                autoDosage.setText("", false);
                autoKekerapan.setText("", false);
                autoArahan.setText("", false);
            }).addOnFailureListener(e -> {
                Toast.makeText(this, "Failed to add: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            });
        }
    }
}