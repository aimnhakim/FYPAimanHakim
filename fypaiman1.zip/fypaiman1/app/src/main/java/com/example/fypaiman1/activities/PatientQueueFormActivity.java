package com.example.fypaiman1.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.fypaiman1.R;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class PatientQueueFormActivity extends AppCompatActivity {

    private TextInputEditText etSymptoms;
    private Button btnSubmitQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_queue_form);

        // --- 1. SETUP TOOLBAR WITH BACK BUTTON ---
        Toolbar toolbar = findViewById(R.id.toolbarQueueForm);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());

        // --- 2. BIND UI COMPONENTS ---
        // HANYA TINGGAL SYMPTOMS SAHAJA BERDASARKAN XML BARU
        etSymptoms = findViewById(R.id.etSymptoms);
        btnSubmitQueue = findViewById(R.id.btnSubmitQueue);

        // --- 3. SUBMIT BUTTON CLICK LISTENER ---
        btnSubmitQueue.setOnClickListener(v -> submitForm());
    }

    private void submitForm() {
        String symptoms = etSymptoms.getText().toString().trim();

        // Validation - pastikan pesakit isi simptom
        if (TextUtils.isEmpty(symptoms)) {
            Toast.makeText(this, "Please state your symptoms!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Dapatkan maklumat User yang tengah login
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser == null) {
            Toast.makeText(this, "Error: User not logged in!", Toast.LENGTH_SHORT).show();
            return;
        }
        String patientId = currentUser.getUid();

        // Ambil nama penuh dari database "Users" sebelum buat nombor giliran
        DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("Users").child(patientId);
        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String fullName = "Unknown Patient";
                // Semak kalau data nama wujud dalam profil user ni
                if (snapshot.exists() && snapshot.hasChild("fullName")) {
                    fullName = snapshot.child("fullName").getValue(String.class);
                }

                // Terus jana nombor giliran lepas dapat nama automatik
                generateQueueNumber(patientId, fullName, symptoms);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(PatientQueueFormActivity.this, "Failed to get user data.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void generateQueueNumber(String patientId, String fullName, String symptoms) {
        DatabaseReference queueRef = FirebaseDatabase.getInstance().getReference("KlinikQueue");

        queueRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot countSnapshot) {
                // Kira ada berapa pesakit sekarang untuk generate nombor giliran (1001, 1002, dll)
                long patientCount = countSnapshot.getChildrenCount();
                String queueNumber = String.valueOf(1001 + patientCount);

                // Simpan data dalam HashMap (Dah buang matricNo & studyLevel ikut cakap SV)
                HashMap<String, Object> queueData = new HashMap<>();
                queueData.put("queueNumber", queueNumber);
                queueData.put("patientId", patientId);
                queueData.put("patientName", fullName);    // Nama diambil automatik
                queueData.put("symptoms", symptoms);       // Simptom yang ditaip
                queueData.put("status", "Waiting");
                queueData.put("doctorRoom", "Pending");
                queueData.put("timestamp", System.currentTimeMillis());

                // Masukkan data dalam database guna child(queueNumber)
                queueRef.child(queueNumber).setValue(queueData).addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(PatientQueueFormActivity.this, "Successfully joined queue: " + queueNumber, Toast.LENGTH_LONG).show();

                        // Lepas berjaya, terus buka page status untuk tengok nombor
                        Intent intent = new Intent(PatientQueueFormActivity.this, AppointmentStatusActivity.class);
                        startActivity(intent);
                        finish(); // Tutup form ni
                    } else {
                        Toast.makeText(PatientQueueFormActivity.this, "Registration failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(PatientQueueFormActivity.this, "Database Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}