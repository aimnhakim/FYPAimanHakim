package com.example.fypaiman1.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.card.MaterialCardView;

import com.example.fypaiman1.R;
import com.google.firebase.auth.FirebaseAuth;
import com.onesignal.OneSignal;

public class AdminDashboardActivity extends AppCompatActivity {

    private TextView tvAdminName;
    private MaterialCardView cardManageUsers, cardManageQueue, cardPharmacy, cardAddNews;
    private Button btnLogout;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);

        mAuth = FirebaseAuth.getInstance();

        // 1. Kenal pasti ID komponen UI
        tvAdminName = findViewById(R.id.tvAdminName);
        cardManageUsers = findViewById(R.id.cardManageUsers);
        cardManageQueue = findViewById(R.id.cardManageQueue);
        cardPharmacy = findViewById(R.id.cardPharmacy);
        cardAddNews = findViewById(R.id.cardAddNews);
        btnLogout = findViewById(R.id.btnLogout);

        // 2. FUNGSI URUS PENGGUNA
        cardManageUsers.setOnClickListener(v -> {
            Intent intent = new Intent(AdminDashboardActivity.this, AdminManageUsersActivity.class);
            startActivity(intent);
        });

        // 3. FUNGSI PANTAU GILIRAN
        cardManageQueue.setOnClickListener(v -> {
            Intent intent = new Intent(AdminDashboardActivity.this, AdminManageQueueActivity.class);
            startActivity(intent);
        });

        // 4. FUNGSI FARMASI
        cardPharmacy.setOnClickListener(v -> {
            Intent intent = new Intent(AdminDashboardActivity.this, AdminPharmacyActivity.class);
            startActivity(intent);
        });

        // 5. FUNGSI URUS BERITA/ACARA (TUKAR KE PAGE MANAGE NEWS LIST)
        cardAddNews.setOnClickListener(v -> {
            Intent intent = new Intent(AdminDashboardActivity.this, AdminManageNewsActivity.class);
            startActivity(intent);
        });

        // 6. KOD LOGOUT
        btnLogout.setOnClickListener(v -> {
            SharedPreferences prefs = getSharedPreferences("KlinikSession", MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.clear();
            editor.apply();

            OneSignal.logout();
            mAuth.signOut();

            Toast.makeText(AdminDashboardActivity.this, "Successfully Logged Out", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(AdminDashboardActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }
}