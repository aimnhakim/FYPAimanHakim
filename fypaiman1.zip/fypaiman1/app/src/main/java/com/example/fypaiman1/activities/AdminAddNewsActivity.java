package com.example.fypaiman1.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.fypaiman1.R;
import com.example.fypaiman1.models.NewsItem;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AdminAddNewsActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;
    private Spinner spinnerType;
    private TextInputEditText etNewsTitle, etNewsDesc;
    private ImageView ivPreviewImage;
    private MaterialButton btnSelectImage, btnSubmitNews;

    private Uri imageUri;
    private DatabaseReference databaseRef;
    private ProgressDialog progressDialog;

    // Untuk Edit Mode
    private String editId = null;
    private String existingBase64 = null;

    // URL Singapore sebagai global variable
    private final String FIREBASE_URL = "https://finalyearproject-f9e19-default-rtdb.asia-southeast1.firebasedatabase.app/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_add_news);

        // --- SETUP TOOLBAR & BACK BUTTON ---
        androidx.appcompat.widget.Toolbar toolbarAddNews = findViewById(R.id.toolbarAddNews);
        setSupportActionBar(toolbarAddNews);

        // Bila ikon back di XML diklik, ia akan tutup skrin ini dan patah balik
        toolbarAddNews.setNavigationOnClickListener(v -> finish());
        // ------------------------------------

        spinnerType = findViewById(R.id.spinnerType);
        etNewsTitle = findViewById(R.id.etNewsTitle);
        etNewsDesc = findViewById(R.id.etNewsDesc);
        ivPreviewImage = findViewById(R.id.ivPreviewImage);
        btnSelectImage = findViewById(R.id.btnSelectImage);
        btnSubmitNews = findViewById(R.id.btnSubmitNews);

        // Masukkan URL Singapore dekat reference database
        databaseRef = FirebaseDatabase.getInstance(FIREBASE_URL).getReference("NewsEvents");

        String[] types = {"News", "Events"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, types);
        spinnerType.setAdapter(adapter);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Processing data...");

        // CHECK IF EDIT MODE
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("id")) {
            editId = intent.getStringExtra("id");
            etNewsTitle.setText(intent.getStringExtra("title"));
            etNewsDesc.setText(intent.getStringExtra("desc"));
            existingBase64 = intent.getStringExtra("imageUrl");

            if ("Events".equals(intent.getStringExtra("type"))) spinnerType.setSelection(1);

            if (existingBase64 != null) {
                byte[] decodedString = Base64.decode(existingBase64, Base64.DEFAULT);
                Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                ivPreviewImage.setImageBitmap(decodedByte);
            }

            // Kekalkan "ADD DATA" ikut kehendak rekaan asal kau bro
            btnSubmitNews.setText("ADD DATA");
        }

        btnSelectImage.setOnClickListener(v -> openFileChooser());
        btnSubmitNews.setOnClickListener(v -> processAndUpload());
    }

    private void openFileChooser() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null) {
            imageUri = data.getData();
            ivPreviewImage.setImageURI(imageUri);
        }
    }

    private void processAndUpload() {
        String title = etNewsTitle.getText().toString().trim();
        String desc = etNewsDesc.getText().toString().trim();
        String type = spinnerType.getSelectedItem().toString();

        if (title.isEmpty() || desc.isEmpty()) {
            Toast.makeText(this, "Fill in all fields!", Toast.LENGTH_SHORT).show();
            return;
        }

        progressDialog.show();

        if (imageUri != null) {
            // Convert gambar baru ke Base64
            try {
                InputStream inputStream = getContentResolver().openInputStream(imageUri);
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);

                // Resize sikit supaya database tak berat
                Bitmap scaledBitmap = Bitmap.createScaledBitmap(bitmap, 600, 400, true);

                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 70, baos);
                byte[] imageBytes = baos.toByteArray();
                String base64Image = Base64.encodeToString(imageBytes, Base64.DEFAULT);

                saveToDatabase(title, desc, type, base64Image);
            } catch (Exception e) {
                progressDialog.dismiss();
                Toast.makeText(this, "Error processing image", Toast.LENGTH_SHORT).show();
            }
        } else if (editId != null && existingBase64 != null) {
            // Guna gambar lama kalau edit tapi tak tukar gambar
            saveToDatabase(title, desc, type, existingBase64);
        } else {
            progressDialog.dismiss();
            Toast.makeText(this, "Please select an image!", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveToDatabase(String title, String desc, String type, String imageData) {
        String id = (editId != null) ? editId : databaseRef.push().getKey();
        String date = new SimpleDateFormat("MMM dd, yyyy", Locale.ENGLISH).format(new Date());
        long timestamp = System.currentTimeMillis();

        NewsItem newsItem = new NewsItem(id, title, desc, type, date, imageData, timestamp);

        databaseRef.child(id).setValue(newsItem).addOnSuccessListener(aVoid -> {
            progressDialog.dismiss();
            Toast.makeText(this, "Success!", Toast.LENGTH_SHORT).show();
            finish();
        }).addOnFailureListener(e -> {
            progressDialog.dismiss();
            Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        });
    }
}