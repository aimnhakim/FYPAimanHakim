package com.example.fypaiman1.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageButton; // <--- Import baru ditambah
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fypaiman1.R;
import com.example.fypaiman1.models.Medication;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MedicationAdapter extends RecyclerView.Adapter<MedicationAdapter.ViewHolder> {

    private List<Medication> medicationList;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onEditClick(Medication med);
        void onDeleteClick(Medication med);
        // Function to send checkbox status to database
        void onCheckChange(Medication med, int timeIndex, boolean isChecked);
    }

    public MedicationAdapter(List<Medication> medicationList, OnItemClickListener listener) {
        this.medicationList = medicationList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_medication, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Medication med = medicationList.get(position);
        holder.tvMedName.setText(med.medName);
        holder.tvMedDosage.setText("Dosage: " + med.dosage);

        // Reset listeners temporarily to avoid triggering false updates during binding
        holder.cbTime1.setOnCheckedChangeListener(null);
        holder.cbTime2.setOnCheckedChangeListener(null);
        holder.cbTime3.setOnCheckedChangeListener(null);

        // --- SETUP BOX 1 ---
        holder.cbTime1.setVisibility(View.VISIBLE);
        holder.cbTime1.setText(med.time1);

        if (med.taken1) {
            holder.cbTime1.setChecked(true);
            holder.cbTime1.setEnabled(false); // Terus lock kalau dah makan
        } else {
            holder.cbTime1.setChecked(false);
            holder.cbTime1.setEnabled(isTimeReached(med.time1)); // Check masa, kalau belum sampai kelabukan button
        }

        // --- SETUP BOX 2 ---
        if (med.frequency >= 2) {
            holder.cbTime2.setVisibility(View.VISIBLE);
            holder.cbTime2.setText(med.time2);

            if (med.taken2) {
                holder.cbTime2.setChecked(true);
                holder.cbTime2.setEnabled(false);
            } else {
                holder.cbTime2.setChecked(false);
                holder.cbTime2.setEnabled(isTimeReached(med.time2));
            }
        } else {
            holder.cbTime2.setVisibility(View.GONE);
        }

        // --- SETUP BOX 3 ---
        if (med.frequency == 3) {
            holder.cbTime3.setVisibility(View.VISIBLE);
            holder.cbTime3.setText(med.time3);

            if (med.taken3) {
                holder.cbTime3.setChecked(true);
                holder.cbTime3.setEnabled(false);
            } else {
                holder.cbTime3.setChecked(false);
                holder.cbTime3.setEnabled(isTimeReached(med.time3));
            }
        } else {
            holder.cbTime3.setVisibility(View.GONE);
        }

        // --- CHECKBOX ACTIONS ---
        // Logik baru: Bila tick, terus lock dan hantar data ke database. Kalau dia cuba untick, halang dia.

        holder.cbTime1.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (buttonView.isPressed()) {
                if (isChecked) {
                    buttonView.setEnabled(false); // Kunci butang
                    listener.onCheckChange(med, 1, true); // Update database
                } else {
                    buttonView.setChecked(true); // Halang pesakit dari untick
                }
            }
        });

        holder.cbTime2.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (buttonView.isPressed()) {
                if (isChecked) {
                    buttonView.setEnabled(false);
                    listener.onCheckChange(med, 2, true);
                } else {
                    buttonView.setChecked(true);
                }
            }
        });

        holder.cbTime3.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (buttonView.isPressed()) {
                if (isChecked) {
                    buttonView.setEnabled(false);
                    listener.onCheckChange(med, 3, true);
                } else {
                    buttonView.setChecked(true);
                }
            }
        });

        // Edit & Delete button actions
        holder.btnEdit.setOnClickListener(v -> listener.onEditClick(med));
        holder.btnDelete.setOnClickListener(v -> listener.onDeleteClick(med));
    }

    @Override
    public int getItemCount() {
        return medicationList.size();
    }

    // --- FUNGSI KHAS UNTUK CHECK MASA SEKARANG VS MASA UBAT ---
    private boolean isTimeReached(String timeStr) {
        if (timeStr == null || timeStr.isEmpty()) return false;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a", Locale.getDefault());
            Date medDate = sdf.parse(timeStr);
            if (medDate == null) return false;

            Calendar medCal = Calendar.getInstance();
            medCal.setTime(medDate);

            Calendar nowCal = Calendar.getInstance();

            // Ambil jam (format 24 jam supaya senang banding) dan minit
            int nowHour = nowCal.get(Calendar.HOUR_OF_DAY);
            int nowMin = nowCal.get(Calendar.MINUTE);

            int medHour = medCal.get(Calendar.HOUR_OF_DAY);
            int medMin = medCal.get(Calendar.MINUTE);

            // Kalau jam sekarang lebih dari jam ubat ATAU (jam sama tapi minit dah lebih/sama)
            if (nowHour > medHour || (nowHour == medHour && nowMin >= medMin)) {
                return true; // Dah boleh tick
            }
            return false; // Belum masuk waktu
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvMedName, tvMedDosage;
        ImageButton btnEdit, btnDelete; // <--- TUKAR KE IMAGEBUTTON (Penyelesaian Crash)
        CheckBox cbTime1, cbTime2, cbTime3;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvMedName = itemView.findViewById(R.id.tvMedName);
            tvMedDosage = itemView.findViewById(R.id.tvMedDosage);

            cbTime1 = itemView.findViewById(R.id.cbTime1);
            cbTime2 = itemView.findViewById(R.id.cbTime2);
            cbTime3 = itemView.findViewById(R.id.cbTime3);

            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}