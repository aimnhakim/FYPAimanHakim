package com.example.fypaiman1.models;

public class NewsItem {
    private String id;
    private String title;
    private String desc;
    private String type;
    private String date;
    private String imageUrl;
    private long timestamp;

    // Empty constructor WAJIB ada untuk Firebase
    public NewsItem() {
    }

    public NewsItem(String id, String title, String desc, String type, String date, String imageUrl, long timestamp) {
        this.id = id;
        this.title = title;
        this.desc = desc;
        this.type = type;
        this.date = date;
        this.imageUrl = imageUrl;
        this.timestamp = timestamp;
    }

    // Getters
    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getDesc() { return desc; }
    public String getType() { return type; }
    public String getDate() { return date; }
    public String getImageUrl() { return imageUrl; }
    public long getTimestamp() { return timestamp; }

    // Setters
    public void setId(String id) { this.id = id; }
    public void setTitle(String title) { this.title = title; }
    public void setDesc(String desc) { this.desc = desc; }
    public void setType(String type) { this.type = type; }
    public void setDate(String date) { this.date = date; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
}