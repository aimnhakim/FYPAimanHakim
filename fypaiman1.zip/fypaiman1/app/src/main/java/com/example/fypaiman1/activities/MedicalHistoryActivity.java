package com.example.fypaiman1.activities;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fypaiman1.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MedicalHistoryActivity extends AppCompatActivity {

    private RecyclerView rvMedicalHistory;
    private TextView tvNoHistory, tvVisitCount;
    private Toolbar toolbar;
    private Spinner spinnerMonth, spinnerSort;

    private DatabaseReference queueRef;
    private FirebaseUser currentUser;

    private HistoryAdapter adapter;
    private List<HistoryModel> originalList; // Simpan semua data dari Firebase
    private List<HistoryModel> filteredList; // Data yang dah difilter untuk ditunjuk

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medical_history);

        // 1. SETUP TOOLBAR
        toolbar = findViewById(R.id.toolbarMedicalHistory);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        // 2. BIND UI COMPONENTS
        rvMedicalHistory = findViewById(R.id.rvMedicalHistory);
        tvNoHistory = findViewById(R.id.tvNoHistory);
        tvVisitCount = findViewById(R.id.tvVisitCount);
        spinnerMonth = findViewById(R.id.spinnerMonth);
        spinnerSort = findViewById(R.id.spinnerSort);

        rvMedicalHistory.setLayoutManager(new LinearLayoutManager(this));
        originalList = new ArrayList<>();
        filteredList = new ArrayList<>();
        adapter = new HistoryAdapter(filteredList);
        rvMedicalHistory.setAdapter(adapter);

        // 3. SETUP SPINNERS
        setupSpinners();

        // 4. LOAD DATA DARI FIREBASE
        currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            queueRef = FirebaseDatabase.getInstance().getReference("KlinikQueue");
            loadMedicalHistory();
        } else {
            tvNoHistory.setVisibility(View.VISIBLE);
        }
    }

    private void setupSpinners() {
        // Setup Bulan (All, Jan, Feb, etc.)
        String[] months = {"All Months", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
        ArrayAdapter<String> monthAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, months);
        spinnerMonth.setAdapter(monthAdapter);

        // Setup Sort (Terbaru -> Lama, Lama -> Terbaru)
        String[] sortOptions = {"Newest First", "Oldest First"};
        ArrayAdapter<String> sortAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, sortOptions);
        spinnerSort.setAdapter(sortAdapter);

        // Listeners bila user tukar pilihan kat Spinner
        AdapterView.OnItemSelectedListener filterListener = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                applyFilterAndSort(); // Panggil fungsi filter setiap kali tukar pilihan
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        };

        spinnerMonth.setOnItemSelectedListener(filterListener);
        spinnerSort.setOnItemSelectedListener(filterListener);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void loadMedicalHistory() {
        String patientId = currentUser.getUid();

        queueRef.orderByChild("patientId").equalTo(patientId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                originalList.clear();

                for (DataSnapshot data : snapshot.getChildren()) {
                    String status = data.child("status").getValue(String.class);

                    if (status != null && status.equals("Completed")) {
                        Object dateObj = data.child("timestamp").getValue();
                        Object symptomObj = data.child("symptoms").getValue();

                        long rawTimestamp = 0;
                        String date = "Unknown Date";

                        if (dateObj != null) {
                            try {
                                rawTimestamp = Long.parseLong(String.valueOf(dateObj));
                                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy, hh:mm a", Locale.getDefault());
                                date = sdf.format(new Date(rawTimestamp));
                            } catch (Exception e) {
                                date = String.valueOf(dateObj);
                            }
                        }

                        String symptom = (symptomObj != null) ? String.valueOf(symptomObj) : "No details";

                        // --- KOD BACA UBAT DARI FOLDER 'prescriptions' ---
                        StringBuilder medsBuilder = new StringBuilder();
                        DataSnapshot prescriptionsSnapshot = data.child("prescriptions");

                        if (prescriptionsSnapshot.exists()) {
                            // Loop untuk keluarkan semua ubat yang doktor bagi
                            for (DataSnapshot medData : prescriptionsSnapshot.getChildren()) {

                                // GUNA EJAAN "namaUbat" SEBIJI MACAM DALAM FIREBASE
                                String namaUbatTepat = medData.child("namaUbat").getValue(String.class);
                                String dosage = medData.child("dosage").getValue(String.class);

                                if (namaUbatTepat != null) {
                                    if (medsBuilder.length() > 0) {
                                        medsBuilder.append("\n"); // Buat baris baru kalau ubat > 1
                                    }
                                    // Format: • Paracetamol (1 Tablet)
                                    medsBuilder.append("• ").append(namaUbatTepat);
                                    if (dosage != null && !dosage.isEmpty()) {
                                        medsBuilder.append(" (").append(dosage).append(")");
                                    }
                                }
                            }
                        }

                        // Kalau ada ubat, pakai senarai ubat tu. Kalau takde baru tulis "No medication"
                        String meds = (medsBuilder.length() > 0) ? medsBuilder.toString() : "No medication prescribed";
                        // -------------------------------------------------------------

                        // Simpan rawTimestamp sekali untuk senang sort dan filter
                        originalList.add(new HistoryModel(date, symptom, meds, rawTimestamp));
                    }
                }

                // Lepas habis load semua, kita panggil fungsi filter untuk tunjukkan data
                applyFilterAndSort();
            }

            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    // FUNGSI UTAMA UNTUK FILTER DAN SORT
    private void applyFilterAndSort() {
        filteredList.clear();

        int selectedMonthIndex = spinnerMonth.getSelectedItemPosition(); // 0 = All, 1 = Jan, 2 = Feb...
        int selectedSortIndex = spinnerSort.getSelectedItemPosition(); // 0 = Newest, 1 = Oldest

        Calendar calendar = Calendar.getInstance();

        // 1. FILTER IKUT BULAN
        for (HistoryModel model : originalList) {
            if (selectedMonthIndex == 0) {
                // Pilih 'All Months', masuk je semua
                filteredList.add(model);
            } else {
                // Check kalau bulan sama macam yang dipilih (Calendar.MONTH mula dari 0 = Jan)
                calendar.setTimeInMillis(model.rawTimestamp);
                int recordMonth = calendar.get(Calendar.MONTH);

                if (recordMonth == (selectedMonthIndex - 1)) {
                    filteredList.add(model);
                }
            }
        }

        // 2. SORT IKUT MASA TERBARU / LAMA
        Collections.sort(filteredList, (m1, m2) -> {
            if (selectedSortIndex == 0) {
                // Newest First (Descending)
                return Long.compare(m2.rawTimestamp, m1.rawTimestamp);
            } else {
                // Oldest First (Ascending)
                return Long.compare(m1.rawTimestamp, m2.rawTimestamp);
            }
        });

        // 3. UPDATE UI
        adapter.notifyDataSetChanged();

        // Update tulisan kiraan kedatangan klinik
        tvVisitCount.setText("Total Visits: " + filteredList.size());

        if (filteredList.isEmpty()) {
            tvNoHistory.setVisibility(View.VISIBLE);
            rvMedicalHistory.setVisibility(View.GONE);
        } else {
            tvNoHistory.setVisibility(View.GONE);
            rvMedicalHistory.setVisibility(View.VISIBLE);
        }
    }

    // --- INNER CLASSES (Model & Adapter) ---
    public static class HistoryModel {
        String date, symptom, medication;
        long rawTimestamp; // TAMBAH NI SUPAYA SENANG NAK KIRA/SORT

        public HistoryModel(String date, String symptom, String medication, long rawTimestamp) {
            this.date = date;
            this.symptom = symptom;
            this.medication = medication;
            this.rawTimestamp = rawTimestamp;
        }
    }

    public static class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.ViewHolder> {
        private final List<HistoryModel> list;
        public HistoryAdapter(List<HistoryModel> list) { this.list = list; }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_medical_history, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            HistoryModel model = list.get(position);
            holder.tvDate.setText("Date: " + model.date);
            holder.tvSymptom.setText("Symptom: " + model.symptom);
            holder.tvMeds.setText("Medication: \n" + model.medication); // Tambah \n sikit biar ubat tu turun bawah cantik
        }

        @Override
        public int getItemCount() { return list.size(); }

        public static class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvDate, tvSymptom, tvMeds;
            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                tvDate = itemView.findViewById(R.id.tvHistoryDate);
                tvSymptom = itemView.findViewById(R.id.tvHistorySymptom);
                tvMeds = itemView.findViewById(R.id.tvHistoryMeds);
            }
        }
    }
}