package com.example.fypaiman1.models;

public class Appointment {
    public String appointmentId;
    public String patientId;
    public String patientName;
    public String queueNumber;
    public long timestamp;
    public String status; // "Pending", "Called", "Completed"

    public Appointment() {} // Wajib ada

    public Appointment(String appointmentId, String patientId, String patientName, String queueNumber, long timestamp) {
        this.appointmentId = appointmentId;
        this.patientId = patientId;
        this.patientName = patientName;
        this.queueNumber = queueNumber;
        this.timestamp = timestamp;
        this.status = "Pending";
    }
}