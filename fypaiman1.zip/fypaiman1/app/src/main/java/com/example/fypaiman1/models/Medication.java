package com.example.fypaiman1.models;

public class Medication {
    public String medId;
    public String patientId;
    public String medName;
    public String dosage;
    public int frequency;
    public String time1;
    public String time2;
    public String time3;

    // Status dah makan atau belum
    public boolean taken1;
    public boolean taken2;
    public boolean taken3;

    // BARU: Untuk simpan tarikh terakhir reset/kemaskini
    public String lastResetDate;

    // Constructor kosong wajib untuk Firebase
    public Medication() {}

    // Constructor penuh yang dikemaskini
    public Medication(String medId, String patientId, String medName, String dosage, int frequency,
                      String time1, String time2, String time3,
                      boolean taken1, boolean taken2, boolean taken3,
                      String lastResetDate) {
        this.medId = medId;
        this.patientId = patientId;
        this.medName = medName;
        this.dosage = dosage;
        this.frequency = frequency;
        this.time1 = time1;
        this.time2 = time2;
        this.time3 = time3;
        this.taken1 = taken1;
        this.taken2 = taken2;
        this.taken3 = taken3;
        this.lastResetDate = lastResetDate;
    }
}