package com.example.fypaiman1.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fypaiman1.R;
import com.example.fypaiman1.adapters.NewsEventAdapter;
import com.example.fypaiman1.models.NewsItem;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class NewsEventsActivity extends AppCompatActivity {

    private Spinner spinnerFilter, spinnerSort;
    private RecyclerView recyclerViewNews;
    private LinearLayout layoutEmptyNews; // Tambah variable untuk Empty State

    private NewsEventAdapter newsEventAdapter;
    private List<NewsItem> allNewsList; // Simpan semua data asal
    private List<NewsItem> filteredList; // Senarai untuk dipaparkan lepas filter/sort
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_events);

        // 1. Setup Toolbar
        Toolbar toolbarNewsEvents = findViewById(R.id.toolbarNewsEvents);
        setSupportActionBar(toolbarNewsEvents);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        toolbarNewsEvents.setNavigationOnClickListener(v -> finish());

        // 2. Bind Empty State Layout
        layoutEmptyNews = findViewById(R.id.layoutEmptyNews);

        // 3. Setup RecyclerView
        recyclerViewNews = findViewById(R.id.recyclerViewNews);
        recyclerViewNews.setHasFixedSize(true);
        recyclerViewNews.setLayoutManager(new LinearLayoutManager(this));

        allNewsList = new ArrayList<>();
        filteredList = new ArrayList<>();
        newsEventAdapter = new NewsEventAdapter(this, filteredList);
        recyclerViewNews.setAdapter(newsEventAdapter);

        // 4. Setup Firebase
        databaseReference = FirebaseDatabase.getInstance().getReference("NewsEvents");

        // 5. Setup Spinners
        spinnerFilter = findViewById(R.id.spinnerFilter);
        spinnerSort = findViewById(R.id.spinnerSort);

        setupSpinners();

        // 6. Fetch Data from Firebase
        fetchNewsEvents();
    }

    private void setupSpinners() {
        // Adapter untuk Filter
        String[] filterOptions = {"All", "News", "Events"};
        ArrayAdapter<String> filterAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, filterOptions);
        spinnerFilter.setAdapter(filterAdapter);

        // Adapter untuk Sort
        String[] sortOptions = {"Newest", "Oldest"};
        ArrayAdapter<String> sortAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, sortOptions);
        spinnerSort.setAdapter(sortAdapter);

        // Listener bila user pilih Filter
        spinnerFilter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                applyFilterAndSort();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        // Listener bila user pilih Sort
        spinnerSort.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                applyFilterAndSort();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void fetchNewsEvents() {
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                allNewsList.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    NewsItem newsItem = dataSnapshot.getValue(NewsItem.class);
                    if (newsItem != null) {
                        allNewsList.add(newsItem);
                    }
                }
                applyFilterAndSort(); // Update list lepas data masuk
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(NewsEventsActivity.this, "Failed to load: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void applyFilterAndSort() {
        String selectedFilter = spinnerFilter.getSelectedItem().toString();
        String selectedSort = spinnerSort.getSelectedItem().toString();

        filteredList.clear();

        // 1. Proses Filtering
        for (NewsItem item : allNewsList) {
            if (selectedFilter.equals("All")) {
                filteredList.add(item);
            } else if (item.getType().equalsIgnoreCase(selectedFilter)) {
                filteredList.add(item);
            }
        }

        // 2. Proses Sorting (Berdasarkan timestamp)
        Collections.sort(filteredList, (o1, o2) -> {
            if (selectedSort.equals("Newest")) {
                return Long.compare(o2.getTimestamp(), o1.getTimestamp()); // Menurun
            } else {
                return Long.compare(o1.getTimestamp(), o2.getTimestamp()); // Menaik
            }
        });

        newsEventAdapter.notifyDataSetChanged();

        // 3. LOGIK EMPTY STATE (Semak lepas filter)
        if (filteredList.isEmpty()) {
            layoutEmptyNews.setVisibility(View.VISIBLE);
            recyclerViewNews.setVisibility(View.GONE);
        } else {
            layoutEmptyNews.setVisibility(View.GONE);
            recyclerViewNews.setVisibility(View.VISIBLE);
        }
    }
}