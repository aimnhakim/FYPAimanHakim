package com.example.fypaiman1.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fypaiman1.R;
import com.example.fypaiman1.adapters.PharmacyAdapter;
import com.example.fypaiman1.models.QueueItem;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class AdminPharmacyActivity extends AppCompatActivity {

    private RecyclerView rvPharmacyQueue;
    private LinearLayout layoutEmptyPharmacy; // Tambah variable untuk Empty State
    private PharmacyAdapter adapter;
    private List<QueueItem> queueList;
    private DatabaseReference dbRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Pastikan layout name: activity_admin_pharmacy
        setContentView(R.layout.activity_admin_pharmacy);

        // --- 1. SETUP TOOLBAR (MODERN STYLE) ---
        Toolbar toolbar = findViewById(R.id.toolbarPharmacy);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Pharmacy Management"); // Tajuk English
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());

        // --- 2. BIND UI COMPONENTS ---
        rvPharmacyQueue = findViewById(R.id.rvPharmacyQueue);
        layoutEmptyPharmacy = findViewById(R.id.layoutEmptyPharmacy); // Bind Empty State dari XML

        rvPharmacyQueue.setLayoutManager(new LinearLayoutManager(this));

        queueList = new ArrayList<>();
        adapter = new PharmacyAdapter(this, queueList);
        rvPharmacyQueue.setAdapter(adapter);

        dbRef = FirebaseDatabase.getInstance().getReference("KlinikQueue");

        // --- 3. LIVE FILTER FOR PHARMACY STATUS ---
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                queueList.clear();
                for (DataSnapshot data : snapshot.getChildren()) {
                    QueueItem item = data.getValue(QueueItem.class);

                    // Logic Tapis: Kita guna "Pharmacy" (atau "Farmasi" ikut string DB hg)
                    // Aku buat check dua-dua supaya tak ada data tercicir
                    if (item != null) {
                        String status = item.getStatus();
                        if ("Pharmacy".equalsIgnoreCase(status) || "Farmasi".equalsIgnoreCase(status)) {
                            queueList.add(item);
                        }
                    }
                }

                // --- LOGIK EMPTY STATE ---
                // Kalau senarai farmasi kosong, tunjuk mesej dan sorok senarai
                if (queueList.isEmpty()) {
                    layoutEmptyPharmacy.setVisibility(View.VISIBLE);
                    rvPharmacyQueue.setVisibility(View.GONE);
                } else {
                    // Kalau ada data, tunjuk senarai dan sorok mesej
                    layoutEmptyPharmacy.setVisibility(View.GONE);
                    rvPharmacyQueue.setVisibility(View.VISIBLE);
                }

                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(AdminPharmacyActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}