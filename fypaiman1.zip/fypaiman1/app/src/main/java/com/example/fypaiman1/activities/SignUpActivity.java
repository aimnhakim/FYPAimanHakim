package com.example.fypaiman1.activities;

import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.fypaiman1.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class SignUpActivity extends AppCompatActivity {

    private static final String TAG = "SignUpActivity";

    private EditText etFullName, etEmail, etPassword, etMatricId, etPhone;
    private Spinner spinnerRole;
    private Button btnRegister;
    private Toolbar toolbarSignup;

    private FirebaseAuth mAuth;
    private FirebaseDatabase mFirebaseDatabase; // Simpan instance database secara berasingan

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        // 1. Initialize Firebase dengan cara paling selamat untuk server Asia
        mAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance("https://finalyearproject-f9e19-default-rtdb.asia-southeast1.firebasedatabase.app");

        // Bind UI Components
        etFullName = findViewById(R.id.etFullName);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etMatricId = findViewById(R.id.etMatricId);
        etPhone = findViewById(R.id.etPhone);
        spinnerRole = findViewById(R.id.spinnerRole);
        btnRegister = findViewById(R.id.btnRegister);
        toolbarSignup = findViewById(R.id.toolbarSignup);

        // Setup Toolbar & Back Button
        setSupportActionBar(toolbarSignup);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Sign Up");
        }
        toolbarSignup.setNavigationOnClickListener(v -> finish());

        // Setup Roles Spinner
        String[] roles = {"Patient", "Doctor", "Admin"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, roles);
        spinnerRole.setAdapter(adapter);

        // Register Action
        btnRegister.setOnClickListener(v -> registerUser());
    }

    private void registerUser() {
        String fullName = etFullName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String matricId = etMatricId.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String role = spinnerRole.getSelectedItem().toString();

        // 1. Basic Validation
        if (fullName.isEmpty() || email.isEmpty() || password.isEmpty() || matricId.isEmpty() || phone.isEmpty()) {
            Toast.makeText(this, "All fields are required!", Toast.LENGTH_SHORT).show();
            return;
        }

        // 2. Matric ID Validation
        if (!matricId.matches("\\d{10}")) {
            etMatricId.setError("Matric ID must be exactly 10 digits");
            return;
        }

        // 3. Phone Number Validation
        if (!phone.matches("\\d{10,11}")) {
            etPhone.setError("Phone number must be 10 or 11 digits");
            return;
        }

        // 4. Password Security Validation
        if (password.length() < 8) {
            etPassword.setError("Minimum 8 characters required");
            return;
        }
        if (!password.matches(".*[A-Z].*")) {
            etPassword.setError("Must contain at least 1 uppercase letter");
            return;
        }
        if (!password.matches(".*[^a-zA-Z0-9].*")) {
            etPassword.setError("Must contain at least 1 symbol (@, #, etc)");
            return;
        }

        // 5. Firebase Auth Registration
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        String userId = mAuth.getCurrentUser().getUid();
                        Log.d(TAG, "Auth Berjaya. UID: " + userId);

                        // Sediakan HashMap data pengguna
                        HashMap<String, Object> userData = new HashMap<>();
                        userData.put("fullName", fullName);
                        userData.put("email", email);
                        userData.put("role", role);
                        userData.put("matricId", matricId);
                        userData.put("phone", phone);
                        userData.put("allergies", "");

                        // Dapatkan database reference secara direct ke "Users/[userId]"
                        DatabaseReference userRef = mFirebaseDatabase.getReference("Users").child(userId);

                        // Save user details to Realtime Database dengan Failure Listener
                        userRef.setValue(userData)
                                .addOnCompleteListener(dbTask -> {
                                    if (dbTask.isSuccessful()) {
                                        Log.d(TAG, "Database Berjaya Simpan!");
                                        Toast.makeText(SignUpActivity.this, "Registration Successful!", Toast.LENGTH_LONG).show();
                                        finish();
                                    } else {
                                        String errorMsg = dbTask.getException() != null ? dbTask.getException().getMessage() : "Unknown DB Error";
                                        Log.e(TAG, "Database Gagal: " + errorMsg);
                                        Toast.makeText(SignUpActivity.this, "DB Task Failed: " + errorMsg, Toast.LENGTH_LONG).show();
                                    }
                                })
                                .addOnFailureListener(e -> {
                                    // PENTING: Bahagian ni akan tangkap kalau internet sekat atau crash network!
                                    Log.e(TAG, "Database Network Failure: " + e.getMessage(), e);
                                    Toast.makeText(SignUpActivity.this, "Network Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                                });

                    } else {
                        String authError = task.getException() != null ? task.getException().getMessage() : "Unknown Auth Error";
                        Log.e(TAG, "Auth Gagal: " + authError);
                        Toast.makeText(SignUpActivity.this, "Authentication Failed: " + authError, Toast.LENGTH_LONG).show();
                    }
                });
    }
}