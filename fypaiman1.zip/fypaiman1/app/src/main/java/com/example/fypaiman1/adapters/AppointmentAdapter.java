package com.example.fypaiman1.adapters;

public class AppointmentAdapter {
}
