package com.example.fypaiman1.activities;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.fypaiman1.R;

public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        // Cari Toolbar dari fail XML
        Toolbar toolbarAbout = findViewById(R.id.toolbarAbout);
        setSupportActionBar(toolbarAbout);

        // Paparkan butang "Back" kat sebelah kiri Toolbar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        // Fungsi bila pesakit tekan butang "Back"
        toolbarAbout.setNavigationOnClickListener(v -> {
            finish(); // Tutup page About dan balik ke Dashboard
        });
    }
}