package com.example.fypaiman1.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.fypaiman1.R;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class DoctorConsultationActivity extends AppCompatActivity {

    private TextView tvQueueId, tvPatientName, tvSymptom;
    private MaterialButton btnFarmasi, btnSelesai;
    private String queueId, patientName;

    // 🔥 FIX: Setup URL Singapore sebagai pembolehubah global supaya senang guna
    private final String FIREBASE_URL = "https://finalyearproject-f9e19-default-rtdb.asia-southeast1.firebasedatabase.app/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_consultation);

        // --- 1. SETUP TOOLBAR ---
        Toolbar toolbar = findViewById(R.id.toolbarConsultation);
        setSupportActionBar(toolbar);

        // 🔥 FIX TOOLBAR: Kod butang back aku dah buang/komen sejajar dengan pertukaran XML kau tadi
        // if (getSupportActionBar() != null) {
        //     getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //     getSupportActionBar().setDisplayShowHomeEnabled(true);
        // }
        // toolbar.setNavigationOnClickListener(v -> getOnBackPressedDispatcher().onBackPressed());

        // --- 2. BIND UI COMPONENTS ---
        tvQueueId = findViewById(R.id.tvQueueId);
        tvPatientName = findViewById(R.id.tvPatientName);
        tvSymptom = findViewById(R.id.tvSymptom);
        btnFarmasi = findViewById(R.id.btnFarmasi);
        btnSelesai = findViewById(R.id.btnSelesai);

        // --- 3. TANGKAP DATA DARI INTENT ---
        queueId = getIntent().getStringExtra("QUEUE_ID"); // cth: "1003"
        patientName = getIntent().getStringExtra("PATIENT_NAME");

        if (queueId != null) {
            tvQueueId.setText(queueId);
            tvPatientName.setText(patientName != null ? patientName : "No Name");

            // Panggil fungsi tarik simptom
            fetchSymptomFromFirebase(queueId);

            // 🔥 EXTRA FIX (Penting!): Bila masuk je skrin ni, kita paksa update status jadi "Consulting"
            updateStatusToConsulting(queueId);

        } else {
            tvQueueId.setText("-");
            tvPatientName.setText("Data Missing");
        }

        // --- 4. LOGIK BUTANG SEND TO PHARMACY ---
        btnFarmasi.setOnClickListener(v -> {
            if (queueId != null) {
                Intent intent = new Intent(this, DoctorPrescriptionActivity.class);
                intent.putExtra("QUEUE_ID", queueId);
                intent.putExtra("PATIENT_NAME", patientName);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Error: Patient ID is missing!", Toast.LENGTH_SHORT).show();
            }
        });

        // --- 5. LOGIK BUTANG COMPLETE (DISCHARGE) ---
        btnSelesai.setOnClickListener(v -> {
            if (queueId != null) {
                // 🔥 FIX: Masukkan URL Singapore
                DatabaseReference dbRef = FirebaseDatabase.getInstance(FIREBASE_URL).getReference("KlinikQueue");

                dbRef.orderByChild("queueNumber").equalTo(queueId).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            for (DataSnapshot data : snapshot.getChildren()) {
                                // Jumpa! Baru kita update status dia ke Completed
                                data.getRef().child("status").setValue("Completed").addOnSuccessListener(aVoid -> {
                                    SharedPreferences prefs = getSharedPreferences("KlinikSession", MODE_PRIVATE);
                                    prefs.edit().remove("active_queue_id").remove("active_patient_name").apply();

                                    Toast.makeText(DoctorConsultationActivity.this, "Treatment Completed!", Toast.LENGTH_SHORT).show();
                                    finish();
                                });
                                return; // Selesai loop
                            }
                        } else {
                            // Backup carian in case queueNumber jenis Integer
                            searchByIntegerQueueNumberAndComplete(queueId, dbRef);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(DoctorConsultationActivity.this, "Database Error!", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        // --- 6. HALANG BUTANG BACK ---
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                Toast.makeText(DoctorConsultationActivity.this, "Please complete treatment first!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // --- FUNGSI AMBIL SIMPTOM (DIBETULKAN DENGAN URL SINGAPORE) ---
    private void fetchSymptomFromFirebase(String qId) {
        // 🔥 FIX: Masukkan URL Singapore
        DatabaseReference dbRef = FirebaseDatabase.getInstance(FIREBASE_URL).getReference("KlinikQueue");

        dbRef.orderByChild("queueNumber").equalTo(qId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    for (DataSnapshot data : snapshot.getChildren()) {
                        String symptom = data.child("symptoms").getValue(String.class);
                        tvSymptom.setText("Symptom: " + (symptom != null ? symptom : "No description"));
                        return;
                    }
                } else {
                    // Cuba cari guna format Integer kalau format String gagal
                    searchSymptomByIntegerQueueNumber(qId, dbRef);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                tvSymptom.setText("Error loading symptoms");
            }
        });
    }

    // --- FUNGSI BARU: UPDATE STATUS KE "CONSULTING" ---
    private void updateStatusToConsulting(String qId) {
        DatabaseReference dbRef = FirebaseDatabase.getInstance(FIREBASE_URL).getReference("KlinikQueue");
        dbRef.orderByChild("queueNumber").equalTo(qId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    for (DataSnapshot data : snapshot.getChildren()) {
                        data.getRef().child("status").setValue("Consulting");
                        return;
                    }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    // --- FAIL-SAFE: CARIAN BACKUP KALAU QUEUENUMBER JENIS INTEGER ---
    private void searchSymptomByIntegerQueueNumber(String qId, DatabaseReference dbRef) {
        try {
            int queueNumInt = Integer.parseInt(qId);
            dbRef.orderByChild("queueNumber").equalTo(queueNumInt).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        for (DataSnapshot data : snapshot.getChildren()) {
                            String symptom = data.child("symptoms").getValue(String.class);
                            tvSymptom.setText("Symptom: " + (symptom != null ? symptom : "No description"));
                            return;
                        }
                    } else {
                        tvSymptom.setText("Symptom: Not specified");
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError error) {}
            });
        } catch (NumberFormatException e) {
            tvSymptom.setText("Symptom: Not specified");
        }
    }

    private void searchByIntegerQueueNumberAndComplete(String qId, DatabaseReference dbRef) {
        try {
            int queueNumInt = Integer.parseInt(qId);
            dbRef.orderByChild("queueNumber").equalTo(queueNumInt).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        for (DataSnapshot data : snapshot.getChildren()) {
                            data.getRef().child("status").setValue("Completed").addOnSuccessListener(aVoid -> {
                                SharedPreferences prefs = getSharedPreferences("KlinikSession", MODE_PRIVATE);
                                prefs.edit().remove("active_queue_id").remove("active_patient_name").apply();
                                Toast.makeText(DoctorConsultationActivity.this, "Treatment Completed!", Toast.LENGTH_SHORT).show();
                                finish();
                            });
                            return;
                        }
                    } else {
                        Toast.makeText(DoctorConsultationActivity.this, "Error: Data pesakit tak wujud", Toast.LENGTH_SHORT).show();
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError error) {}
            });
        } catch (NumberFormatException e) {
            Toast.makeText(DoctorConsultationActivity.this, "Error: Invalid Queue ID format", Toast.LENGTH_SHORT).show();
        }
    }
}