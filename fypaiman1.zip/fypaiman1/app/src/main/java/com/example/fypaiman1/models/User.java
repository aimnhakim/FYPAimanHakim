package com.example.fypaiman1.models;

public class User {
    public String fullName;
    public String email;
    public String role;
    public String room; // <-- INI KITA TAMBAH UNTUK DOKTOR

    // Constructor kosong (Wajib ada untuk Firebase)
    public User() {
    }

    // Constructor masa daftar
    public User(String fullName, String email, String role) {
        this.fullName = fullName;
        this.email = email;
        this.role = role;
        this.room = ""; // <-- Masa mula-mula daftar, kita set bilik dia kosong
    }
}