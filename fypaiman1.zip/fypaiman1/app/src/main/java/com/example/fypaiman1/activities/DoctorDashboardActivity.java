package com.example.fypaiman1.activities;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View; // <--- IMPORT BARU UNTUK VISIBILITY
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fypaiman1.R;
import com.example.fypaiman1.adapters.QueueAdapter;
import com.example.fypaiman1.models.QueueItem;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class DoctorDashboardActivity extends AppCompatActivity {

    private RecyclerView rvDoctorQueue;
    private Button btnLogOut;
    private TextView tvDoctorName;
    private TextView tvNoQueue; // <--- KOD BARU: Declare TextView untuk ayat kosong

    private QueueAdapter adapter;
    private List<QueueItem> queueList;
    private DatabaseReference dbRefQueue;
    private DatabaseReference dbRefRooms;
    private DatabaseReference dbRefMyRoom;

    private String roomNumber = null;
    private SharedPreferences prefs;
    private String currentDoctorId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_dashboard);

        rvDoctorQueue = findViewById(R.id.rvDoctorQueue);
        btnLogOut = findViewById(R.id.btnLogOut);
        tvDoctorName = findViewById(R.id.tvDoctorName);
        tvNoQueue = findViewById(R.id.tvNoQueue); // <--- KOD BARU: Hubungkan dengan ID XML

        rvDoctorQueue.setLayoutManager(new LinearLayoutManager(this));

        prefs = getSharedPreferences("KlinikSession", Context.MODE_PRIVATE);

        // --- Semak login status dulu ---
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser == null) {
            Toast.makeText(this, "Session expired. Please login again.", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(DoctorDashboardActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
            return;
        }

        currentDoctorId = currentUser.getUid();

        // --- TARIK NAMA DOKTOR DARI FIREBASE ---
        DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("Users").child(currentDoctorId);
        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String namaSebenar = snapshot.child("fullName").getValue(String.class);
                    if (namaSebenar != null) {
                        if (namaSebenar.toLowerCase().startsWith("dr")) {
                            tvDoctorName.setText(namaSebenar);
                        } else {
                            tvDoctorName.setText("Dr. " + namaSebenar);
                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });

        dbRefRooms = FirebaseDatabase.getInstance().getReference("KlinikRooms");
        dbRefMyRoom = FirebaseDatabase.getInstance().getReference("DoctorRooms").child(currentDoctorId);

        // Semak bilik kekal doktor
        semakBilikKekalDoktor();

        // KOD LOG KELUAR
        btnLogOut.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            Toast.makeText(DoctorDashboardActivity.this, "Log Out Successful!", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(DoctorDashboardActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    // --- FUNGSI SEMAK BILIK KEKAL DOKTOR ---
    private void semakBilikKekalDoktor() {
        dbRefMyRoom.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    roomNumber = snapshot.getValue(String.class);
                    Toast.makeText(DoctorDashboardActivity.this, "Active at: " + roomNumber, Toast.LENGTH_SHORT).show();
                    setupDashboard();
                } else {
                    semakBilikKosong();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(DoctorDashboardActivity.this, "Database Error", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // --- FUNGSI CARI BILIK KOSONG ---
    private void semakBilikKosong() {
        dbRefRooms.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<String> bilikKosong = new ArrayList<>();
                String[] semuaBilik = {"Room 1", "Room 2", "Room 3"};

                for (String bilik : semuaBilik) {
                    if (!snapshot.child(bilik).exists() || "Available".equals(snapshot.child(bilik).getValue(String.class))) {
                        bilikKosong.add(bilik);
                    }
                }

                if (bilikKosong.isEmpty()) {
                    Toast.makeText(DoctorDashboardActivity.this, "Sorry, all rooms are occupied!", Toast.LENGTH_LONG).show();
                } else {
                    tunjukDialogPilihBilik(bilikKosong);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    // --- FUNGSI POPUP PILIH BILIK ---
    private void tunjukDialogPilihBilik(List<String> bilikKosong) {
        String[] arrayBilikKosong = bilikKosong.toArray(new String[0]);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Assign Permanent Room");
        builder.setCancelable(false);

        builder.setItems(arrayBilikKosong, (dialog, which) -> {
            roomNumber = arrayBilikKosong[which];

            dbRefMyRoom.setValue(roomNumber);
            dbRefRooms.child(roomNumber).setValue("Occupied");

            Toast.makeText(this, "Registered to " + roomNumber, Toast.LENGTH_SHORT).show();
            setupDashboard();
        });
        builder.show();
    }

    // --- FUNGSI LOAD DASHBOARD & SENARAI PESAKIT ---
    private void setupDashboard() {
        queueList = new ArrayList<>();
        adapter = new QueueAdapter(this, queueList, roomNumber);
        rvDoctorQueue.setAdapter(adapter);

        dbRefQueue = FirebaseDatabase.getInstance().getReference("KlinikQueue");
        dbRefQueue.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                queueList.clear();
                for (DataSnapshot data : snapshot.getChildren()) {
                    QueueItem item = data.getValue(QueueItem.class);
                    if (item != null && "Waiting".equals(item.getStatus())) {
                        queueList.add(item);
                    }
                }
                adapter.notifyDataSetChanged();

                // --- KOD BARU: Tunjuk ayat kalau takde queue ---
                if (queueList.isEmpty()) {
                    rvDoctorQueue.setVisibility(View.GONE); // Sorok list
                    tvNoQueue.setVisibility(View.VISIBLE);  // Tunjuk ayat "Tiada pesakit"
                } else {
                    rvDoctorQueue.setVisibility(View.VISIBLE); // Tunjuk list
                    tvNoQueue.setVisibility(View.GONE);        // Sorok ayat
                }
                // -----------------------------------------------
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });

        checkActiveSession();
    }

    // --- FUNGSI FAILSAFE PESAKIT SEMASA ---
    private void checkActiveSession() {
        String activeId = prefs.getString("active_queue_id", null);
        String activeName = prefs.getString("active_patient_name", null);

        if (activeId != null) {
            goToConsultation(activeId, activeName);
        } else {
            DatabaseReference dbRefQ = FirebaseDatabase.getInstance().getReference("KlinikQueue");
            dbRefQ.orderByChild("status").equalTo("Consulting").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    for (DataSnapshot data : snapshot.getChildren()) {
                        QueueItem item = data.getValue(QueueItem.class);
                        if (item != null) {
                            SharedPreferences.Editor editor = prefs.edit();
                            editor.putString("active_queue_id", item.getQueueId());
                            editor.putString("active_patient_name", item.getPatientName());
                            editor.apply();

                            goToConsultation(item.getQueueId(), item.getPatientName());
                            break;
                        }
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError error) {}
            });
        }
    }

    private void goToConsultation(String queueId, String patientName) {
        Intent intent = new Intent(this, DoctorConsultationActivity.class);
        intent.putExtra("QUEUE_ID", queueId);
        intent.putExtra("PATIENT_NAME", patientName);
        startActivity(intent);
    }
}