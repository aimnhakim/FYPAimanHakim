package com.example.fypaiman1.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fypaiman1.R;
import com.example.fypaiman1.adapters.UserAdapter;
import com.example.fypaiman1.models.User;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class AdminManageUsersActivity extends AppCompatActivity {

    private RecyclerView rvManageUsers;
    private FloatingActionButton fabAddUser;
    private ChipGroup chipGroupRole;
    private LinearLayout layoutEmptyState; // Tambah variable untuk Empty State

    private UserAdapter adapter;

    // List untuk simpan semua data dari Firebase
    private List<User> fullUserList;
    private List<String> fullKeyList;

    // List untuk papar data yang dah di-filter ke RecyclerView
    private List<User> displayUserList;
    private List<String> displayKeyList;

    private DatabaseReference dbRef;
    private String currentFilter = "All"; // Default filter

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_manage_users); // Pastikan nama layout XML betul

        // --- 1. SETUP TOOLBAR ---
        Toolbar toolbar = findViewById(R.id.toolbarManageUsers);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Manage Users");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());

        // --- 2. BIND UI COMPONENTS ---
        rvManageUsers = findViewById(R.id.rvManageUsers);
        fabAddUser = findViewById(R.id.fabAddUser);
        chipGroupRole = findViewById(R.id.chipGroupRole);
        layoutEmptyState = findViewById(R.id.layoutEmptyState); // Bind Empty State dari XML

        rvManageUsers.setLayoutManager(new LinearLayoutManager(this));

        // Initialize Lists
        fullUserList = new ArrayList<>();
        fullKeyList = new ArrayList<>();
        displayUserList = new ArrayList<>();
        displayKeyList = new ArrayList<>();

        // Adapter guna display list (yang dah filter)
        adapter = new UserAdapter(this, displayUserList, displayKeyList);
        rvManageUsers.setAdapter(adapter);

        // --- 3. LOGIK FILTER (CHIP GROUP) ---
        chipGroupRole.setOnCheckedStateChangeListener((group, checkedIds) -> {
            if (!checkedIds.isEmpty()) {
                int id = checkedIds.get(0);
                if (id == R.id.chipPatient) {
                    currentFilter = "Patient";
                } else if (id == R.id.chipDoctor) {
                    currentFilter = "Doctor";
                } else if (id == R.id.chipAdmin) {
                    currentFilter = "Admin";
                } else {
                    currentFilter = "All";
                }
                applyFilter(); // Panggil method filter bila butang ditekan
            }
        });

        // --- 4. AMBIL DATA DARI FIREBASE ---
        dbRef = FirebaseDatabase.getInstance().getReference("Users");
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                fullUserList.clear();
                fullKeyList.clear();

                for (DataSnapshot ds : snapshot.getChildren()) {
                    User user = ds.getValue(User.class);
                    if (user != null) {
                        fullUserList.add(user);
                        fullKeyList.add(ds.getKey());
                    }
                }
                // Lepas ambil data baru, terus apply filter supaya list update
                applyFilter();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(AdminManageUsersActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        // --- 5. BUTANG TAMBAH USER ---
        fabAddUser.setOnClickListener(v -> {
            Intent intent = new Intent(AdminManageUsersActivity.this, AdminAddUserActivity.class);
            startActivity(intent);
        });
    }

    // METHOD UNTUK ASINGKAN DATA IKUT ROLE DAN URUS EMPTY STATE
    private void applyFilter() {
        displayUserList.clear();
        displayKeyList.clear();

        for (int i = 0; i < fullUserList.size(); i++) {
            User user = fullUserList.get(i);
            String key = fullKeyList.get(i);

            // Kalau "All", masukkan semua
            if (currentFilter.equals("All")) {
                displayUserList.add(user);
                displayKeyList.add(key);
            }
            // Kalau bukan "All", semak adakah role sama dengan filter
            else if (user.role != null && user.role.equalsIgnoreCase(currentFilter)) {
                displayUserList.add(user);
                displayKeyList.add(key);
            }
        }

        // --- LOGIK EMPTY STATE ---
        // Kalau list yang nak dipaparkan kosong, tunjuk mesej dan sorok senarai
        if (displayUserList.isEmpty()) {
            layoutEmptyState.setVisibility(View.VISIBLE);
            rvManageUsers.setVisibility(View.GONE);
        } else {
            // Kalau ada data, tunjuk senarai dan sorok mesej
            layoutEmptyState.setVisibility(View.GONE);
            rvManageUsers.setVisibility(View.VISIBLE);
        }

        // Beritahu adapter yang data dah berubah
        adapter.notifyDataSetChanged();
    }
}