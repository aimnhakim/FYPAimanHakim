package com.example.fypaiman1.activities;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.fypaiman1.R;
import com.example.fypaiman1.models.QueueItem;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

// --- IMPORT ONESIGNAL ---
import com.onesignal.OneSignal;
import com.onesignal.Continue;

import java.util.Calendar;

public class PatientDashboardActivity extends AppCompatActivity {

    private TextView tvPatientName;
    // TAMBAH: cardAbout
    private MaterialCardView cardGetQueue, cardQueueStatus, cardMedReminder, cardMedicalHistory, cardMyProfile, cardNewsEvents, cardAbout;
    private MaterialButton btnLogout;

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    private String currentPatientName = "Patient";
    private static final String ONESIGNAL_APP_ID = "281499fa-c066-4510-9b3b-026569a3d8a6";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_dashboard);

        // 1. Bind UI Components (Ikut 7 kad dalam XML baru)
        tvPatientName = findViewById(R.id.tvPatientName);
        cardGetQueue = findViewById(R.id.cardGetQueue);
        cardQueueStatus = findViewById(R.id.cardQueueStatus);
        cardMedReminder = findViewById(R.id.cardMedReminder);
        cardMedicalHistory = findViewById(R.id.cardMedicalHistory);
        cardMyProfile = findViewById(R.id.cardMyProfile);
        cardNewsEvents = findViewById(R.id.cardNewsEvents);
        cardAbout = findViewById(R.id.cardAbout); // TAMBAH: Bind cardAbout
        btnLogout = findViewById(R.id.btnLogout);

        // 2. Setup Firebase
        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();

        // --- START ONESIGNAL REGISTRATION CODE ---
        OneSignal.initWithContext(this, ONESIGNAL_APP_ID);
        OneSignal.getNotifications().requestPermission(true, Continue.with(r -> {
            if (r.isSuccess()) {
                Log.d("OneSignalDashboard", "Notification Permission: Granted!");
            }
        }));

        if (currentUser != null) {
            OneSignal.login(currentUser.getUid());
        }
        // --- END ONESIGNAL REGISTRATION CODE ---

        loadPatientName();

        // --- CARD CLICKS ---

        // 1. Function: Get Queue Number
        cardGetQueue.setOnClickListener(v -> checkAndOpenQueueForm());

        // 2. Function: Check Queue Status
        cardQueueStatus.setOnClickListener(v -> {
            startActivity(new Intent(this, AppointmentStatusActivity.class));
        });

        // 3. Function: Medication Reminders
        cardMedReminder.setOnClickListener(v -> {
            startActivity(new Intent(this, MedicationReminderActivity.class));
        });

        // 4. Function: Medical History
        cardMedicalHistory.setOnClickListener(v -> {
            startActivity(new Intent(this, MedicalHistoryActivity.class));
        });

        // 5. Function: My Profile
        cardMyProfile.setOnClickListener(v -> {
            startActivity(new Intent(this, PatientProfileActivity.class));
        });

        // 6. Function: News & Events
        cardNewsEvents.setOnClickListener(v -> {
            startActivity(new Intent(this, NewsEventsActivity.class));
        });

        // 7. Function: About
        cardAbout.setOnClickListener(v -> {
            startActivity(new Intent(this, AboutActivity.class));
        });

        // --- LOGOUT CODE ---
        btnLogout.setOnClickListener(v -> {
            SharedPreferences prefs = getSharedPreferences("KlinikSession", MODE_PRIVATE);
            prefs.edit().clear().apply();

            OneSignal.logout();
            mAuth.signOut();

            Toast.makeText(this, "Logged Out Successfully", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    // FUNGSI: Semak waktu operasi & aktif queue sebelum pergi borang
    private void checkAndOpenQueueForm() {
        // --- 1. SEMAK WAKTU OPERASI KLINIK DULU ---
        Calendar calendar = Calendar.getInstance();
        int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK); // Ahad = 1, Isnin = 2, ... Sabtu = 7
        int hourOfDay = calendar.get(Calendar.HOUR_OF_DAY); // Format 24 jam (0-23)
        int minute = calendar.get(Calendar.MINUTE); // 0-59

        // Tukar masa ke format nombor supaya senang compare (Contoh: 8:30 AM jadi 830, 2:45 PM jadi 1445)
        int currentTime = (hourOfDay * 100) + minute;

        boolean isClinicOpen = false;

        if (dayOfWeek == Calendar.SATURDAY || dayOfWeek == Calendar.SUNDAY) {
            // Hujung minggu tutup
            isClinicOpen = false;
        } else if (dayOfWeek == Calendar.FRIDAY) {
            // Jumaat: 8:00 AM (800) - 12:15 PM (1215) ATAU 2:45 PM (1445) - 5:00 PM (1700)
            if ((currentTime >= 800 && currentTime < 1215) || (currentTime >= 1445 && currentTime < 1700)) {
                isClinicOpen = true;
            }
        } else {
            // Isnin - Khamis: 8:00 AM (800) - 1:00 PM (1300) ATAU 2:00 PM (1400) - 5:00 PM (1700)
            if ((currentTime >= 800 && currentTime < 1300) || (currentTime >= 1400 && currentTime < 1700)) {
                isClinicOpen = true;
            }
        }

        // Kalau klinik tutup, tahan pesakit dan keluar mesej guna AlertDialog
        if (!isClinicOpen) {
            new AlertDialog.Builder(this)
                    .setTitle("Clinic is Closed")
                    .setMessage("Sorry, you can only get a queue number during operating hours.\n\n" +
                            "Mon - Thu: 8:00 AM - 1:00 PM & 2:00 PM - 5:00 PM\n" +
                            "Friday: 8:00 AM - 12:15 PM & 2:45 PM - 5:00 PM\n" +
                            "Sat & Sun: CLOSED")
                    .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
                    .setCancelable(false)
                    .show();
            return; // Berhenti kat sini, tak payah check queue kat Firebase
        }

        // --- 2. KALAU BUKA, BARU SEMAK QUEUE AKTIF KAT FIREBASE ---
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;

        String patientId = currentUser.getUid();
        DatabaseReference queueRef = FirebaseDatabase.getInstance().getReference("KlinikQueue");

        queueRef.orderByChild("patientId").equalTo(patientId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                boolean hasActiveQueue = false;
                for (DataSnapshot data : snapshot.getChildren()) {
                    String status = data.child("status").getValue(String.class);
                    // Kalau ada queue yang belum siap/cancel, kira aktif
                    if (status != null && !status.equals("Completed") && !status.equals("Cancelled")) {
                        hasActiveQueue = true;
                        break;
                    }
                }

                if (hasActiveQueue) {
                    Toast.makeText(PatientDashboardActivity.this, "You already have an active queue number!", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = new Intent(PatientDashboardActivity.this, PatientQueueFormActivity.class);
                    startActivity(intent);
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    // FUNGSI: Tarik nama sebenar pesakit dari Firebase
    private void loadPatientName() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            String userId = currentUser.getUid();
            DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("Users").child(userId);

            userRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        String fullName = snapshot.child("fullName").getValue(String.class);
                        if (fullName != null) {
                            currentPatientName = fullName;
                            tvPatientName.setText(fullName);
                        }
                    }
                }
                @Override public void onCancelled(@NonNull DatabaseError error) {}
            });
        }
    }
}