package com.example.fypaiman1.adapters;

import android.content.Context;
import android.content.Intent;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.fypaiman1.R;
import com.example.fypaiman1.activities.AdminAddNewsActivity;
import com.example.fypaiman1.models.NewsItem;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class AdminNewsAdapter extends RecyclerView.Adapter<AdminNewsAdapter.ViewHolder> {

    private Context context;
    private List<NewsItem> newsList;

    public AdminNewsAdapter(Context context, List<NewsItem> newsList) {
        this.context = context;
        this.newsList = newsList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_admin_news, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        NewsItem item = newsList.get(position);

        holder.tvTitle.setText(item.getTitle());
        holder.tvDate.setText("🕒 " + item.getDate());

        // KOD DIBETULKAN DI SINI: Tukar "Kategori: " jadi "Category: "
        holder.tvCategory.setText("Category: " + item.getType());

        // PROSES CONVERT BASE64 KE GAMBAR
        if (item.getImageUrl() != null && !item.getImageUrl().isEmpty()) {
            try {
                byte[] decodedString = Base64.decode(item.getImageUrl(), Base64.DEFAULT);
                Glide.with(context)
                        .asBitmap()
                        .load(decodedString)
                        .placeholder(R.drawable.ic_launcher_background)
                        .into(holder.ivNewsImage);
            } catch (Exception e) {
                // Kalau tiba-tiba data lama ada link web biasa
                Glide.with(context)
                        .load(item.getImageUrl())
                        .placeholder(R.drawable.ic_launcher_background)
                        .into(holder.ivNewsImage);
            }
        }

        // FUNGSI BUTANG DELETE
        holder.btnDelete.setOnClickListener(v -> {
            new AlertDialog.Builder(context)
                    .setTitle("Delete Confirmation")
                    .setMessage("Are you sure you want to delete this?")
                    .setPositiveButton("Yes, Delete", (dialog, which) -> {
                        FirebaseDatabase.getInstance().getReference("NewsEvents")
                                .child(item.getId()).removeValue()
                                .addOnSuccessListener(aVoid -> Toast.makeText(context, "Deleted successfully", Toast.LENGTH_SHORT).show());
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        // FUNGSI BUTANG EDIT
        holder.btnEdit.setOnClickListener(v -> {
            Intent intent = new Intent(context, AdminAddNewsActivity.class);
            intent.putExtra("id", item.getId());
            intent.putExtra("title", item.getTitle());
            intent.putExtra("desc", item.getDesc()); // Pastikan getDesc() ni dah tak merah lepas letak NewsItem baru
            intent.putExtra("type", item.getType());
            intent.putExtra("imageUrl", item.getImageUrl());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return newsList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle, tvCategory, tvDate;
        ImageView ivNewsImage;
        MaterialButton btnEdit, btnDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvCategory = itemView.findViewById(R.id.tvCategory);
            tvDate = itemView.findViewById(R.id.tvDate);
            ivNewsImage = itemView.findViewById(R.id.ivNewsImage);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}