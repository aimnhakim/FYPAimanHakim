package com.example.fypaiman1.activities;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.core.app.NotificationCompat;

import com.example.fypaiman1.R;

public class MedicationAlarmReceiver extends BroadcastReceiver {

    private static final String CHANNEL_ID = "MedicationChannel";

    @Override
    public void onReceive(Context context, Intent intent) {
        // Retrieve medication name and dosage from the intent
        String medName = intent.getStringExtra("medName");
        String dosage = intent.getStringExtra("dosage");

        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        // Create Notification Channel for Android 8.0 (Oreo) and above
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Medication Reminders",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Channel for medication intake reminders");
            notificationManager.createNotificationChannel(channel);
        }

        // Setup intent to open the app when the notification is clicked
        Intent repeatingIntent = new Intent(context, MedicationReminderActivity.class);
        repeatingIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                context,
                0,
                repeatingIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        // Design the Notification appearance
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_popup_reminder) // Default Android reminder icon
                .setContentTitle("Time for medication: " + medName)
                .setContentText("Please take " + dosage + " now.")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setVibrate(new long[]{1000, 1000, 1000, 1000, 1000}); // Optional: Add vibration

        // Trigger the Notification (Use current time as ID to prevent overlapping)
        notificationManager.notify((int) System.currentTimeMillis(), builder.build());
    }
}