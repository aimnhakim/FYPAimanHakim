package com.example.fypaiman1.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.fypaiman1.R;
import com.example.fypaiman1.models.User;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AdminAddUserActivity extends AppCompatActivity {

    private EditText etFullName, etEmail, etPassword;
    private Spinner spinnerRole;
    private Button btnRegister;
    private TextView btnBack;

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_add_user);

        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference("Users");

        etFullName = findViewById(R.id.etFullName);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        spinnerRole = findViewById(R.id.spinnerRole);
        btnRegister = findViewById(R.id.btnRegister);
        btnBack = findViewById(R.id.btnBack);

        // Pilihan Peranan untuk Admin daftar
        String[] roles = {"Doctor", "Admin", "Patient"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, roles);
        spinnerRole.setAdapter(adapter);

        // Fungsi butang kembali
        btnBack.setOnClickListener(v -> finish());

        // Fungsi butang daftar
        btnRegister.setOnClickListener(v -> registerUser());
    }

    private void registerUser() {
        String fullName = etFullName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String role = spinnerRole.getSelectedItem().toString();

        // 1. Semak kotak kosong
        if (fullName.isEmpty() || email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Sila isi semua maklumat", Toast.LENGTH_SHORT).show();
            return;
        }

        // --- MULA KOD PENGAWAL KESELAMATAN (SECURITY CHECK) ---
        if (password.length() < 8) {
            Toast.makeText(this, "Password must be at least 8 characters!", Toast.LENGTH_LONG).show();
            etPassword.setError("Minimum 8 characters");
            etPassword.requestFocus();
            return;
        }

        if (!password.matches(".*[A-Z].*")) {
            Toast.makeText(this, "Password must contain at least 1 uppercase letter!", Toast.LENGTH_LONG).show();
            etPassword.setError("Uppercase required");
            etPassword.requestFocus();
            return;
        }

        if (!password.matches(".*[^a-zA-Z0-9].*")) {
            Toast.makeText(this, "Password must contain at least 1 symbol (e.g. @, #, !)", Toast.LENGTH_LONG).show();
            etPassword.setError("Symbol required");
            etPassword.requestFocus();
            return;
        }
        // --- TAMAT KOD PENGAWAL KESELAMATAN ---

        // Firebase Auth & DB
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        String userId = mAuth.getCurrentUser().getUid();

                        // Guna model User hg yang asal
                        User user = new User(fullName, email, role);

                        mDatabase.child(userId).setValue(user).addOnCompleteListener(dbTask -> {
                            if (dbTask.isSuccessful()) {
                                Toast.makeText(AdminAddUserActivity.this, "New User Registered Successfully!", Toast.LENGTH_LONG).show();
                                finish(); // Tutup skrin ni, patah balik ke senarai pengguna
                            } else {
                                Toast.makeText(AdminAddUserActivity.this, "Database Error: " + dbTask.getException().getMessage(), Toast.LENGTH_LONG).show();
                            }
                        });
                    } else {
                        Toast.makeText(AdminAddUserActivity.this, "Registration Failed: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }
}