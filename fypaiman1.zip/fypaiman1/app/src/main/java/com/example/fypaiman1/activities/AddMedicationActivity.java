package com.example.fypaiman1.activities;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.fypaiman1.R;
import com.example.fypaiman1.models.Medication;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AddMedicationActivity extends AppCompatActivity {

    private AutoCompleteTextView autoMedName, autoDosage;
    private EditText etMedTime1, etMedTime2, etMedTime3;
    private RadioGroup rgFrequency;
    private Button btnSaveMedication;
    private Toolbar toolbarAddMed;

    private TextInputLayout tilTime2, tilTime3;

    private DatabaseReference mDatabase;
    private String currentUserId;

    private String editingMedId = null;
    private int selectedFrequency = 1;

    private boolean tempTaken1 = false;
    private boolean tempTaken2 = false;
    private boolean tempTaken3 = false;
    private String existingResetDate = null; // Simpan tarikh lama kalau edit

    private int[] selectedHour = {-1, -1, -1};
    private int[] selectedMinute = {-1, -1, -1};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_medication);

        autoMedName = findViewById(R.id.autoMedName);
        autoDosage = findViewById(R.id.autoDosage);
        rgFrequency = findViewById(R.id.rgFrequency);
        etMedTime1 = findViewById(R.id.etMedTime1);
        etMedTime2 = findViewById(R.id.etMedTime2);
        etMedTime3 = findViewById(R.id.etMedTime3);

        tilTime2 = findViewById(R.id.tilTime2);
        tilTime3 = findViewById(R.id.tilTime3);
        btnSaveMedication = findViewById(R.id.btnSaveMedication);
        toolbarAddMed = findViewById(R.id.toolbarAddMed);

        setSupportActionBar(toolbarAddMed);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        toolbarAddMed.setNavigationOnClickListener(v -> finish());

        currentUserId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        mDatabase = FirebaseDatabase.getInstance().getReference("Medications");

        String[] listUbat = {"Paracetamol", "Ibuprofen", "Amoxicillin", "Vitamin C", "Cough Syrup", "Loratadine"};
        String[] listDos = {"1 Tablet", "2 Tablets", "1 Capsule", "5ml (1 Teaspoon)", "10ml", "1 Sachet"};

        ArrayAdapter<String> adapterUbat = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listUbat);
        autoMedName.setAdapter(adapterUbat);

        ArrayAdapter<String> adapterDos = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listDos);
        autoDosage.setAdapter(adapterDos);

        updateTimeBoxes(1, false);

        rgFrequency.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.rbFreq1) {
                updateTimeBoxes(1, true);
            } else if (checkedId == R.id.rbFreq2) {
                updateTimeBoxes(2, true);
            } else if (checkedId == R.id.rbFreq3) {
                updateTimeBoxes(3, true);
            }
        });

        etMedTime1.setOnClickListener(v -> showTimePicker(1, etMedTime1));
        etMedTime2.setOnClickListener(v -> showTimePicker(2, etMedTime2));
        etMedTime3.setOnClickListener(v -> showTimePicker(3, etMedTime3));

        checkIfEditing();

        btnSaveMedication.setOnClickListener(v -> saveOrUpdateMedication());
    }

    private void updateTimeBoxes(int frequency, boolean showToast) {
        selectedFrequency = frequency;

        if (showToast) {
            Toast.makeText(this, "Changed to: " + frequency + "x daily", Toast.LENGTH_SHORT).show();
        }

        if (tilTime2 == null || tilTime3 == null || etMedTime2 == null || etMedTime3 == null) {
            return;
        }

        if (editingMedId == null) {
            if (frequency == 1) {
                etMedTime1.setText("08:00 AM");
                selectedHour[0] = 8; selectedMinute[0] = 0;
            } else if (frequency == 2) {
                etMedTime1.setText("08:00 AM");
                selectedHour[0] = 8; selectedMinute[0] = 0;
                etMedTime2.setText("08:00 PM");
                selectedHour[1] = 20; selectedMinute[1] = 0;
            } else if (frequency == 3) {
                etMedTime1.setText("08:00 AM");
                selectedHour[0] = 8; selectedMinute[0] = 0;
                etMedTime2.setText("02:00 PM");
                selectedHour[1] = 14; selectedMinute[1] = 0;
                etMedTime3.setText("08:00 PM");
                selectedHour[2] = 20; selectedMinute[2] = 0;
            }
        }

        if (frequency == 1) {
            tilTime2.setVisibility(View.GONE);
            etMedTime2.setVisibility(View.GONE);
            tilTime3.setVisibility(View.GONE);
            etMedTime3.setVisibility(View.GONE);
        } else if (frequency == 2) {
            tilTime2.setVisibility(View.VISIBLE);
            etMedTime2.setVisibility(View.VISIBLE);
            tilTime3.setVisibility(View.GONE);
            etMedTime3.setVisibility(View.GONE);
        } else if (frequency == 3) {
            tilTime2.setVisibility(View.VISIBLE);
            etMedTime2.setVisibility(View.VISIBLE);
            tilTime3.setVisibility(View.VISIBLE);
            etMedTime3.setVisibility(View.VISIBLE);
        }
    }

    private void checkIfEditing() {
        Intent intent = getIntent();
        if (intent.hasExtra("medId")) {
            editingMedId = intent.getStringExtra("medId");

            autoMedName.setText(intent.getStringExtra("medName"), false);
            autoDosage.setText(intent.getStringExtra("dosage"), false);

            selectedFrequency = intent.getIntExtra("frequency", 1);

            if(selectedFrequency == 1) rgFrequency.check(R.id.rbFreq1);
            else if(selectedFrequency == 2) rgFrequency.check(R.id.rbFreq2);
            else if(selectedFrequency == 3) rgFrequency.check(R.id.rbFreq3);

            etMedTime1.setText(intent.getStringExtra("time1"));
            etMedTime2.setText(intent.getStringExtra("time2"));
            etMedTime3.setText(intent.getStringExtra("time3"));

            tempTaken1 = intent.getBooleanExtra("taken1", false);
            tempTaken2 = intent.getBooleanExtra("taken2", false);
            tempTaken3 = intent.getBooleanExtra("taken3", false);
            existingResetDate = intent.getStringExtra("lastResetDate"); // Ambil tarikh asal

            btnSaveMedication.setText("UPDATE MEDICATION");
        }
    }

    private void showTimePicker(int index, EditText et) {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this, (view, hourOfDay, minuteOfHour) -> {
            selectedHour[index - 1] = hourOfDay;
            selectedMinute[index - 1] = minuteOfHour;
            String amPm = (hourOfDay >= 12) ? "PM" : "AM";
            int displayHour = (hourOfDay == 0 || hourOfDay == 12) ? 12 : hourOfDay % 12;
            et.setText(String.format(Locale.getDefault(), "%02d:%02d %s", displayHour, minuteOfHour, amPm));
        }, hour, minute, false);
        timePickerDialog.show();
    }

    private void saveOrUpdateMedication() {
        String name = autoMedName.getText().toString().trim();
        String dosage = autoDosage.getText().toString().trim();
        String t1 = etMedTime1.getText().toString().trim();
        String t2 = selectedFrequency >= 2 ? etMedTime2.getText().toString().trim() : "";
        String t3 = selectedFrequency == 3 ? etMedTime3.getText().toString().trim() : "";

        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(dosage) || TextUtils.isEmpty(t1)) {
            Toast.makeText(this, "Please fill in Name, Dosage, and Time!", Toast.LENGTH_SHORT).show();
            return;
        }

        String finalMedId = (editingMedId == null) ? mDatabase.push().getKey() : editingMedId;

        // --- LOGIK BARU: AMBIL TARIKH HARI INI ---
        String todayDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        String dateToSave = (editingMedId != null && existingResetDate != null) ? existingResetDate : todayDate;

        // SEKARANG ADA 12 PARAMETER (TAMBAH dateToSave KAT HUJUNG)
        Medication med = new Medication(finalMedId, currentUserId, name, dosage, selectedFrequency, t1, t2, t3,
                editingMedId != null && tempTaken1,
                editingMedId != null && tempTaken2,
                editingMedId != null && tempTaken3,
                dateToSave);

        if (finalMedId != null) {
            mDatabase.child(currentUserId).child(finalMedId).setValue(med);
        }

        Toast.makeText(this, editingMedId == null ? "Medication added!" : "Medication updated!", Toast.LENGTH_SHORT).show();

        cancelAlarm(finalMedId, 1);
        cancelAlarm(finalMedId, 2);
        cancelAlarm(finalMedId, 3);

        if (selectedHour[0] != -1) setAlarm(finalMedId, name, dosage, selectedHour[0], selectedMinute[0], 1);
        if (selectedFrequency >= 2 && selectedHour[1] != -1) setAlarm(finalMedId, name, dosage, selectedHour[1], selectedMinute[1], 2);
        if (selectedFrequency == 3 && selectedHour[2] != -1) setAlarm(finalMedId, name, dosage, selectedHour[2], selectedMinute[2], 3);

        finish();
    }

    private void setAlarm(String medId, String name, String dosage, int hour, int minute, int alarmIndex) {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, MedicationAlarmReceiver.class);
        intent.putExtra("medName", name);
        intent.putExtra("dosage", dosage);

        int alarmId = medId.hashCode() + alarmIndex;
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, alarmId, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, minute);
        calendar.set(Calendar.SECOND, 0);

        if (calendar.before(Calendar.getInstance())) {
            calendar.add(Calendar.DATE, 1);
        }

        if (alarmManager != null) {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
        }
    }

    private void cancelAlarm(String medId, int alarmIndex) {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, MedicationAlarmReceiver.class);
        int alarmId = medId.hashCode() + alarmIndex;
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, alarmId, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (alarmManager != null) alarmManager.cancel(pendingIntent);
    }
}