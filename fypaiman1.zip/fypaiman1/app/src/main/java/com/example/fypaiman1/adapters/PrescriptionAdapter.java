package com.example.fypaiman1.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fypaiman1.R;
import com.example.fypaiman1.models.Prescription;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class PrescriptionAdapter extends RecyclerView.Adapter<PrescriptionAdapter.ViewHolder> {

    private Context context;
    private List<Prescription> listUbat;
    private String queueId;

    public PrescriptionAdapter(Context context, List<Prescription> listUbat, String queueId) {
        this.context = context;
        this.listUbat = listUbat;
        this.queueId = queueId;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_prescription, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Prescription ubat = listUbat.get(position);

        // Susun setiap data pada baris masing-masing
        holder.tvNamaUbat.setText("Medication: " + ubat.getNamaUbat());
        holder.tvDosage.setText("Dosage: " + ubat.getDosage()); // <-- Data Dosage kat baris baru
        holder.tvKekerapan.setText("Frequency: " + ubat.getKekerapan());
        holder.tvArahan.setText("Instruction: " + ubat.getArahan());

        holder.btnBuang.setOnClickListener(v -> {
            DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference("KlinikQueue")
                    .child(queueId).child("prescriptions").child(ubat.getId());

            dbRef.removeValue().addOnSuccessListener(aVoid -> {
                Toast.makeText(context, "Medication deleted", Toast.LENGTH_SHORT).show();
            });
        });
    }

    @Override
    public int getItemCount() {
        return listUbat.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        // Tambah tvDosage kat sini
        TextView tvNamaUbat, tvDosage, tvKekerapan, tvArahan;
        ImageButton btnBuang;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNamaUbat = itemView.findViewById(R.id.tvNamaUbat);
            tvDosage = itemView.findViewById(R.id.tvDosage); // <-- Bind ID baru
            tvKekerapan = itemView.findViewById(R.id.tvKekerapan);
            tvArahan = itemView.findViewById(R.id.tvArahan);
            btnBuang = itemView.findViewById(R.id.btnBuang);
        }
    }
}