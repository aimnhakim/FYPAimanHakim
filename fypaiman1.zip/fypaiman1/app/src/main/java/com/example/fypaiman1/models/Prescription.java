package com.example.fypaiman1.models;

public class Prescription {
    public String id;
    public String namaUbat;
    public String dosage; // <-- BARU TAMBAH
    public String kekerapan;
    public String arahan;

    // Wajib ada untuk Firebase
    public Prescription() {}

    public Prescription(String id, String namaUbat, String dosage, String kekerapan, String arahan) {
        this.id = id;
        this.namaUbat = namaUbat;
        this.dosage = dosage; // <-- BARU TAMBAH
        this.kekerapan = kekerapan;
        this.arahan = arahan;
    }

    public String getId() { return id; }
    public String getNamaUbat() { return namaUbat; }
    public String getDosage() { return dosage; } // <-- BARU TAMBAH
    public String getKekerapan() { return kekerapan; }
    public String getArahan() { return arahan; }
}