package com.example.fypaiman1.activities; // Ganti ikut package kau

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fypaiman1.R;
import com.example.fypaiman1.adapters.AdminNewsAdapter;
import com.example.fypaiman1.models.NewsItem;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class AdminManageNewsActivity extends AppCompatActivity {

    private RecyclerView recyclerViewAdminNews;
    private FloatingActionButton fabAddNews;
    private LinearLayout layoutEmptyNews; // Tambah variable untuk Empty State

    private AdminNewsAdapter adapter;
    private List<NewsItem> newsList;
    private DatabaseReference dbRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_manage_news);

        // Setup Toolbar
        Toolbar toolbarAdminNews = findViewById(R.id.toolbarAdminNews);
        setSupportActionBar(toolbarAdminNews);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        toolbarAdminNews.setNavigationOnClickListener(v -> finish());

        // Bind UI Components
        recyclerViewAdminNews = findViewById(R.id.recyclerViewAdminNews);
        fabAddNews = findViewById(R.id.fabAddNews);
        layoutEmptyNews = findViewById(R.id.layoutEmptyNews); // Bind Empty State dari XML

        // Setup RecyclerView
        recyclerViewAdminNews.setHasFixedSize(true);
        recyclerViewAdminNews.setLayoutManager(new LinearLayoutManager(this));

        newsList = new ArrayList<>();
        adapter = new AdminNewsAdapter(this, newsList);
        recyclerViewAdminNews.setAdapter(adapter);

        dbRef = FirebaseDatabase.getInstance().getReference("NewsEvents");

        // Tarik Data
        loadData();

        // Butang Tambah
        fabAddNews.setOnClickListener(v -> {
            startActivity(new Intent(AdminManageNewsActivity.this, AdminAddNewsActivity.class));
        });
    }

    private void loadData() {
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                newsList.clear();
                for (DataSnapshot ds : snapshot.getChildren()) {
                    NewsItem item = ds.getValue(NewsItem.class);
                    if (item != null) {
                        newsList.add(0, item); // Susun yang terbaru kat atas
                    }
                }

                // --- LOGIK EMPTY STATE ---
                // Kalau senarai berita kosong, tunjuk mesej dan sorok senarai
                if (newsList.isEmpty()) {
                    layoutEmptyNews.setVisibility(View.VISIBLE);
                    recyclerViewAdminNews.setVisibility(View.GONE);
                } else {
                    // Kalau ada data, tunjuk senarai dan sorok mesej
                    layoutEmptyNews.setVisibility(View.GONE);
                    recyclerViewAdminNews.setVisibility(View.VISIBLE);
                }

                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(AdminManageNewsActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}