package com.example.fypaiman1.models;

public class QueueItem {
    public String queueId;       // Untuk data format lama (kalau ada)
    public String queueNumber;   // Untuk data format BARU (contoh: 1001)
    public String patientId;
    public String patientName;
    public String status;
    public long timestamp;
    public String roomNumber;

    // 1. Constructor Kosong (Wajib ada untuk Firebase)
    public QueueItem() {}

    // 2. Constructor penuh
    public QueueItem(String queueId, String queueNumber, String patientId, String patientName, String status, long timestamp, String roomNumber) {
        this.queueId = queueId;
        this.queueNumber = queueNumber;
        this.patientId = patientId;
        this.patientName = patientName;
        this.status = status;
        this.timestamp = timestamp;
        this.roomNumber = roomNumber;
    }

    // --- FUNGSI KEBAL NULL (Biar dia auto-pilih mana yang ada isi) ---
    public String getSafeQueueId() {
        if (queueNumber != null && !queueNumber.isEmpty()) {
            return queueNumber;
        }
        return queueId; // Fallback kalau dia guna form lama
    }

    // --- GETTER & SETTER ---
    public String getQueueId() { return queueId; }
    public void setQueueId(String queueId) { this.queueId = queueId; }

    public String getQueueNumber() { return queueNumber; }
    public void setQueueNumber(String queueNumber) { this.queueNumber = queueNumber; }

    public String getPatientId() { return patientId; }
    public void setPatientId(String patientId) { this.patientId = patientId; }

    public String getPatientName() { return patientName; }
    public void setPatientName(String patientName) { this.patientName = patientName; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }

    public String getRoomNumber() { return roomNumber; }
    public void setRoomNumber(String roomNumber) { this.roomNumber = roomNumber; }
}