package com.example.fypaiman1.activities;

import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.fypaiman1.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

// --- IMPORT ONESIGNAL ---
import com.onesignal.OneSignal;

public class AppointmentStatusActivity extends AppCompatActivity {

    private TextView tvNomborGiliran, tvStatusSemasa, tvCurrentServing;
    private Button btnKembali;

    private FirebaseAuth mAuth;
    private DatabaseReference mQueueRef;

    private ValueEventListener queueListener;
    private ValueEventListener allQueueListener;

    private boolean isTimerRunning = false;

    // ID OneSignal Kau
    private static final String ONESIGNAL_APP_ID = "281499fa-c066-4510-9b3b-026569a3d8a6";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment_status);

        tvNomborGiliran = findViewById(R.id.tvNomborGiliran);
        tvStatusSemasa = findViewById(R.id.tvStatusSemasa);
        tvCurrentServing = findViewById(R.id.tvCurrentServing);
        btnKembali = findViewById(R.id.btnKembali);

        mAuth = FirebaseAuth.getInstance();

        // URL Firebase Singapore Kau
        String firebase_url = "https://finalyearproject-f9e19-default-rtdb.asia-southeast1.firebasedatabase.app/";
        mQueueRef = FirebaseDatabase.getInstance(firebase_url).getReference("KlinikQueue");

        // --- ONESIGNAL FAILSAFE SETUP ---
        OneSignal.initWithContext(this, ONESIGNAL_APP_ID);
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            OneSignal.login(currentUser.getUid());
        }

        btnKembali.setOnClickListener(v -> finish());

        checkQueueStatus();
        loadCurrentServing();
    }

    private void checkQueueStatus() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;

        String userId = currentUser.getUid();
        Query query = mQueueRef.orderByChild("patientId").equalTo(userId);

        queueListener = query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    boolean foundActive = false;

                    for (DataSnapshot data : snapshot.getChildren()) {
                        String originalStatus = data.child("status").getValue(String.class);
                        if (originalStatus == null) continue;

                        String status = originalStatus.trim().toLowerCase();

                        if (!status.equals("completed")) {

                            // 🔥 FIX: Guna String.valueOf in-case queueNumber disimpan sebagai Integer/Number kat Firebase
                            Object qNumObj = data.child("queueNumber").getValue();
                            String queueNum = (qNumObj != null) ? String.valueOf(qNumObj) : "";

                            if (queueNum.isEmpty()) {
                                Object qIdObj = data.child("queueId").getValue();
                                queueNum = (qIdObj != null) ? String.valueOf(qIdObj) : "";
                            }
                            if (queueNum.isEmpty()) {
                                queueNum = data.getKey();
                            }

                            tvNomborGiliran.setText(queueNum);
                            foundActive = true;

                            String roomNumber = data.child("roomNumber").getValue(String.class);

                            if (status.equals("waiting")) {
                                tvStatusSemasa.setText("⏳ WAITING FOR CALL\n(Please wait in the lobby)");
                                tvStatusSemasa.setTextColor(getResources().getColor(android.R.color.holo_orange_dark));

                            } else if (status.equals("consulting") || status.equals("calling")) {
                                if (roomNumber != null && !roomNumber.isEmpty()) {
                                    tvStatusSemasa.setText("👨‍⚕️ CONSULTATION SESSION\n(Please proceed to " + roomNumber + ")");
                                } else {
                                    tvStatusSemasa.setText("👨‍⚕️ CONSULTATION SESSION\n(Please proceed to doctor's room)");
                                }
                                tvStatusSemasa.setTextColor(getResources().getColor(android.R.color.holo_blue_dark));

                            } else if (status.equals("pharmacy") || status.equals("farmasi")) {
                                tvStatusSemasa.setText("💊 PLEASE PROCEED TO PHARMACY\n(Your medicine is being prepared)");
                                tvStatusSemasa.setTextColor(getResources().getColor(android.R.color.holo_green_dark));

                                if (!isTimerRunning) {
                                    isTimerRunning = true;
                                    Toast.makeText(AppointmentStatusActivity.this, "Please proceed to pharmacy. Session will end in 1 minute.", Toast.LENGTH_LONG).show();

                                    new Handler().postDelayed(() -> {
                                        data.getRef().child("status").setValue("Completed");
                                        Toast.makeText(AppointmentStatusActivity.this, "Session completed! Medicine collected.", Toast.LENGTH_LONG).show();
                                        finish();
                                    }, 60 * 1000);
                                }
                            }
                            break;
                        }
                    }

                    if (!foundActive) {
                        tvNomborGiliran.setText("-");
                        tvStatusSemasa.setText("No active queue found.");
                        tvStatusSemasa.setTextColor(getResources().getColor(android.R.color.darker_gray));
                    }

                } else {
                    tvNomborGiliran.setText("-");
                    tvStatusSemasa.setText("No active queue found.");
                    tvStatusSemasa.setTextColor(getResources().getColor(android.R.color.darker_gray));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(AppointmentStatusActivity.this, "Queue Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadCurrentServing() {
        allQueueListener = mQueueRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                StringBuilder servingInfo = new StringBuilder("📣 CURRENTLY SERVING:\n\n");
                boolean isSomeoneServed = false;

                for (DataSnapshot data : snapshot.getChildren()) {
                    String status = data.child("status").getValue(String.class);

                    if (status != null) {
                        status = status.trim().toLowerCase();

                        if (status.equals("calling") || status.equals("consulting")) {

                            // 🔥 FIX: Guna String.valueOf juga dekat sini supaya tak null kalau jenis Integer
                            Object qNumObj = data.child("queueNumber").getValue();
                            String queueNum = (qNumObj != null) ? String.valueOf(qNumObj) : "";

                            if (queueNum.isEmpty()) {
                                Object qIdObj = data.child("queueId").getValue();
                                queueNum = (qIdObj != null) ? String.valueOf(qIdObj) : "";
                            }
                            if (queueNum.isEmpty()) {
                                queueNum = data.getKey();
                            }

                            String roomNumber = data.child("roomNumber").getValue(String.class);
                            if (roomNumber == null || roomNumber.isEmpty()) roomNumber = "Doctor's Room";

                            servingInfo.append("▶ ").append(queueNum).append(" (").append(roomNumber).append(")\n");
                            isSomeoneServed = true;
                        }
                    }
                }

                if (!isSomeoneServed) {
                    servingInfo.append("- No active consultations -");
                }

                if (tvCurrentServing != null) {
                    tvCurrentServing.setText(servingInfo.toString().trim());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // 🔥 FIX DIAGNOSIS: Kalau Firebase block, amaran ni AKAN KELUAR kat screen phone kau!
                Toast.makeText(AppointmentStatusActivity.this, "Serving Error: " + error.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mQueueRef != null) {
            if (queueListener != null) mQueueRef.removeEventListener(queueListener);
            if (allQueueListener != null) mQueueRef.removeEventListener(allQueueListener);
        }
    }
}