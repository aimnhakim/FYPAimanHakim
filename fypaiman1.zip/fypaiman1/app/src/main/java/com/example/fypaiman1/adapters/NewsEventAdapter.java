package com.example.fypaiman1.adapters; // Tukar package ikut folder kau

import android.content.Context;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.fypaiman1.R;
import com.example.fypaiman1.models.NewsItem;

import java.util.List;

public class NewsEventAdapter extends RecyclerView.Adapter<NewsEventAdapter.ViewHolder> {

    private Context context;
    private List<NewsItem> newsList;

    public NewsEventAdapter(Context context, List<NewsItem> newsList) {
        this.context = context;
        this.newsList = newsList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_news_event, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        NewsItem item = newsList.get(position);

        holder.tvTitle.setText(item.getTitle());
        holder.tvDesc.setText(item.getDesc());
        holder.tvDate.setText("🕒 Posted on: " + item.getDate());

        if (item.getType().equalsIgnoreCase("Events")) {
            holder.tvCategory.setText("📅 " + item.getType());
        } else {
            holder.tvCategory.setText("📢 " + item.getType());
        }

        // PROSES CONVERT BASE64 KE GAMBAR UNTUK PAPARAN USER
        if (item.getImageUrl() != null && !item.getImageUrl().isEmpty()) {
            try {
                // Tukar teks panjang (Base64) balik jadi gambar
                byte[] decodedString = Base64.decode(item.getImageUrl(), Base64.DEFAULT);
                Glide.with(context)
                        .asBitmap()
                        .load(decodedString)
                        .placeholder(R.drawable.ic_launcher_background) // Gambar sementara sebelum siap load
                        .into(holder.ivNewsImage);
            } catch (Exception e) {
                // Kalau tiba-tiba data lama ada link web biasa, dia guna cara ni
                Glide.with(context)
                        .load(item.getImageUrl())
                        .placeholder(R.drawable.ic_launcher_background)
                        .into(holder.ivNewsImage);
            }
        }
    }

    @Override
    public int getItemCount() {
        return newsList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle, tvDesc, tvCategory, tvDate;
        ImageView ivNewsImage;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvDesc = itemView.findViewById(R.id.tvDesc);
            tvCategory = itemView.findViewById(R.id.tvCategory);
            tvDate = itemView.findViewById(R.id.tvDate);
            ivNewsImage = itemView.findViewById(R.id.ivNewsImage);
        }
    }
}