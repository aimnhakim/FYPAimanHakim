package com.example.fypaiman1.activities;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fypaiman1.R;
import com.example.fypaiman1.adapters.MedicationAdapter;
import com.example.fypaiman1.models.Medication;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MedicationReminderActivity extends AppCompatActivity {

    private RecyclerView rvMedications;
    private FloatingActionButton fabAddMed;
    private Toolbar toolbarMedication;
    private LinearLayout layoutEmptyMedication;

    private MedicationAdapter adapter;
    private List<Medication> medicationList;

    private DatabaseReference mDatabase;
    private String currentUserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medication_reminder);

        rvMedications = findViewById(R.id.rvMedications);
        fabAddMed = findViewById(R.id.fabAddMed);
        toolbarMedication = findViewById(R.id.toolbarMedication);
        layoutEmptyMedication = findViewById(R.id.layoutEmptyMedication);

        setSupportActionBar(toolbarMedication);
        toolbarMedication.setNavigationOnClickListener(v -> finish());

        // --- FIX CRASH: Cek kalau User wujud sebelum panggil UID ---
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            currentUserId = currentUser.getUid();
            mDatabase = FirebaseDatabase.getInstance().getReference("Medications");
        } else {
            // Kalau user tak wujud (sesi tamat), bagi amaran dan tutup skrin
            Toast.makeText(this, "Session expired. Please login again.", Toast.LENGTH_SHORT).show();
            finish();
            return; // Berhenti terus run kod kat bawah
        }

        rvMedications.setLayoutManager(new LinearLayoutManager(this));
        medicationList = new ArrayList<>();

        adapter = new MedicationAdapter(medicationList, new MedicationAdapter.OnItemClickListener() {
            @Override
            public void onEditClick(Medication med) {
                Intent intent = new Intent(MedicationReminderActivity.this, AddMedicationActivity.class);
                intent.putExtra("medId", med.medId);
                intent.putExtra("medName", med.medName);
                intent.putExtra("dosage", med.dosage);
                intent.putExtra("frequency", med.frequency);
                intent.putExtra("time1", med.time1);
                intent.putExtra("time2", med.time2 != null ? med.time2 : "");
                intent.putExtra("time3", med.time3 != null ? med.time3 : "");
                intent.putExtra("taken1", med.taken1);
                intent.putExtra("taken2", med.taken2);
                intent.putExtra("taken3", med.taken3);
                startActivity(intent);
            }

            @Override
            public void onDeleteClick(Medication med) {
                new AlertDialog.Builder(MedicationReminderActivity.this)
                        .setTitle("Delete Medication")
                        .setMessage("Are you sure you want to delete this medication?")
                        .setPositiveButton("Yes", (dialog, which) -> {
                            mDatabase.child(currentUserId).child(med.medId).removeValue();
                            cancelAlarm(med.medId, 1);
                            cancelAlarm(med.medId, 2);
                            cancelAlarm(med.medId, 3);
                            Toast.makeText(MedicationReminderActivity.this, "Medication deleted", Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton("No", null)
                        .show();
            }

            @Override
            public void onCheckChange(Medication med, int timeIndex, boolean isChecked) {
                String todayDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

                if (timeIndex == 1) med.taken1 = isChecked;
                if (timeIndex == 2) med.taken2 = isChecked;
                if (timeIndex == 3) med.taken3 = isChecked;

                med.lastResetDate = todayDate;

                mDatabase.child(currentUserId).child(med.medId).setValue(med);
            }
        });

        rvMedications.setAdapter(adapter);

        fabAddMed.setOnClickListener(v -> {
            startActivity(new Intent(MedicationReminderActivity.this, AddMedicationActivity.class));
        });

        loadMedications();
    }

    private void loadMedications() {
        // Double check untuk elak error sebelum tarik data
        if (currentUserId == null || mDatabase == null) return;

        mDatabase.child(currentUserId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                medicationList.clear();
                String todayDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Medication med = dataSnapshot.getValue(Medication.class);
                    if (med != null) {

                        // --- LOGIK AUTO-RESET SETIAP HARI ---
                        if (med.lastResetDate == null || !med.lastResetDate.equals(todayDate)) {
                            med.taken1 = false;
                            med.taken2 = false;
                            med.taken3 = false;
                            med.lastResetDate = todayDate;

                            mDatabase.child(currentUserId).child(med.medId).setValue(med);
                        }

                        medicationList.add(med);
                    }
                }

                // --- LOGIK EMPTY STATE ---
                if (medicationList.isEmpty()) {
                    layoutEmptyMedication.setVisibility(View.VISIBLE);
                    rvMedications.setVisibility(View.GONE);
                } else {
                    layoutEmptyMedication.setVisibility(View.GONE);
                    rvMedications.setVisibility(View.VISIBLE);
                }

                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MedicationReminderActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void cancelAlarm(String medId, int alarmIndex) {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, MedicationAlarmReceiver.class);
        int alarmId = medId.hashCode() + alarmIndex;
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, alarmId, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (alarmManager != null) alarmManager.cancel(pendingIntent);
    }
}