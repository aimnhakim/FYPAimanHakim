package com.example.fypaiman1.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fypaiman1.R;
import com.example.fypaiman1.models.User;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserViewHolder> {

    private Context context;
    private List<User> userList;
    private List<String> keyList; // To store Firebase IDs

    public UserAdapter(Context context, List<User> userList, List<String> keyList) {
        this.context = context;
        this.userList = userList;
        this.keyList = keyList;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_user, parent, false);
        return new UserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
        User user = userList.get(position);
        String userId = keyList.get(position); // Pull unique user ID

        // DIRECT CALL FROM User.java (NOT USING GETTERS)
        holder.tvUserName.setText(user.fullName);
        holder.tvUserRole.setText("Role: " + user.role);
        holder.tvUserEmail.setText(user.email);

        // Delete button function
        holder.btnDelete.setOnClickListener(v -> {
            new AlertDialog.Builder(context)
                    .setTitle("Delete User")
                    .setMessage("Are you sure you want to delete " + user.fullName + " (" + user.role + ")?")
                    .setPositiveButton("Yes, Delete", (dialog, which) -> {
                        DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference("Users").child(userId);
                        dbRef.removeValue().addOnSuccessListener(aVoid -> {
                            Toast.makeText(context, "User deleted successfully", Toast.LENGTH_SHORT).show();
                        }).addOnFailureListener(e -> {
                            Toast.makeText(context, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        });
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });
    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    public static class UserViewHolder extends RecyclerView.ViewHolder {
        TextView tvUserName, tvUserRole, tvUserEmail;
        ImageButton btnDelete; // Renamed from btnPadam

        public UserViewHolder(@NonNull View itemView) {
            super(itemView);
            tvUserName = itemView.findViewById(R.id.tvUserName);
            tvUserRole = itemView.findViewById(R.id.tvUserRole);
            tvUserEmail = itemView.findViewById(R.id.tvUserEmail);
            btnDelete = itemView.findViewById(R.id.btnPadamUser); // ID stays btnPadamUser unless changed in XML
        }
    }
}